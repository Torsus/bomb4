// OddsLas.cpp : implementation file
//

#include "stdafx.h"
#include "bomb.h"
#include "OddsLas.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COddsLas dialog


COddsLas::COddsLas(CWnd* pParent /*=NULL*/)
	: CDialog(COddsLas::IDD, pParent)
{
	//{{AFX_DATA_INIT(COddsLas)
	m_AntalInlastaOdds = 0;
	m_upprepa = FALSE;
	m_MissadeSidor = 0;
	m_maxsida1 = 0;
	m_maxsida10 = 0;
	m_maxsida2 = 0;
	m_maxsida3 = 0;
	m_maxsida4 = 0;
	m_maxsida5 = 0;
	m_maxsida6 = 0;
	m_maxsida7 = 0;
	m_maxsida8 = 0;
	m_maxsida9 = 0;
	m_minsida1 = 0;
	m_minsida10 = 0;
	m_minsida2 = 0;
	m_minsida3 = 0;
	m_minsida4 = 0;
	m_minsida5 = 0;
	m_minsida6 = 0;
	m_minsida7 = 0;
	m_minsida8 = 0;
	m_minsida9 = 0;
	m_MissadeSidor2 = 0;
	m_MissadeSidor10 = 0;
	m_MissadeSidor3 = 0;
	m_MissadeSidor4 = 0;
	m_MissadeSidor5 = 0;
	m_MissadeSidor6 = 0;
	m_MissadeSidor7 = 0;
	m_MissadeSidor8 = 0;
	m_MissadeSidor9 = 0;
	m_Instanser = 0;
	m_InlastaOdds1 = 0;
	m_InlastaOdds2 = 0;
	m_InlastaOdds3 = 0;
	m_InlastaOdds4 = 0;
	m_InlastaOdds5 = 0;
	m_InlastaOdds6 = 0;
	m_InlastaOdds7 = 0;
	m_InlastaOdds8 = 0;
	m_InlastaOdds9 = 0;
	m_InlastaOdds10 = 0;
	//}}AFX_DATA_INIT
}


void COddsLas::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(COddsLas)
	DDX_Control(pDX, IDC_PROGRESS9, m_progress9);
	DDX_Control(pDX, IDC_PROGRESS8, m_progress8);
	DDX_Control(pDX, IDC_PROGRESS7, m_progress7);
	DDX_Control(pDX, IDC_PROGRESS6, m_progress6);
	DDX_Control(pDX, IDC_PROGRESS5, m_progress5);
	DDX_Control(pDX, IDC_PROGRESS4, m_progress4);
	DDX_Control(pDX, IDC_PROGRESS3, m_progress3);
	DDX_Control(pDX, IDC_PROGRESS10, m_progress10);
	DDX_Control(pDX, IDC_PROGRESS2, m_progress2);
	DDX_Control(pDX, IDC_PROGRESS1, m_progress);
	DDX_Text(pDX, IDC_EDIT1, m_AntalInlastaOdds);
	DDX_Check(pDX, IDC_CHECK_UPPREPA, m_upprepa);
	DDX_Text(pDX, IDC_MISSADESIDOR, m_MissadeSidor);
	DDX_Text(pDX, IDC_MAXSIDA1, m_maxsida1);
	DDX_Text(pDX, IDC_MAXSIDA10, m_maxsida10);
	DDX_Text(pDX, IDC_MAXSIDA2, m_maxsida2);
	DDX_Text(pDX, IDC_MAXSIDA3, m_maxsida3);
	DDX_Text(pDX, IDC_MAXSIDA4, m_maxsida4);
	DDX_Text(pDX, IDC_MAXSIDA5, m_maxsida5);
	DDX_Text(pDX, IDC_MAXSIDA6, m_maxsida6);
	DDX_Text(pDX, IDC_MAXSIDA7, m_maxsida7);
	DDX_Text(pDX, IDC_MAXSIDA8, m_maxsida8);
	DDX_Text(pDX, IDC_MAXSIDA9, m_maxsida9);
	DDX_Text(pDX, IDC_STARTSIDA1, m_minsida1);
	DDX_Text(pDX, IDC_STARTSIDA10, m_minsida10);
	DDX_Text(pDX, IDC_STARTSIDA2, m_minsida2);
	DDX_Text(pDX, IDC_STARTSIDA3, m_minsida3);
	DDX_Text(pDX, IDC_STARTSIDA4, m_minsida4);
	DDX_Text(pDX, IDC_STARTSIDA5, m_minsida5);
	DDX_Text(pDX, IDC_STARTSIDA6, m_minsida6);
	DDX_Text(pDX, IDC_STARTSIDA7, m_minsida7);
	DDX_Text(pDX, IDC_STARTSIDA8, m_minsida8);
	DDX_Text(pDX, IDC_STARTSIDA9, m_minsida9);
	DDX_Text(pDX, IDC_MISSADESIDOR2, m_MissadeSidor2);
	DDX_Text(pDX, IDC_MISSADESIDOR10, m_MissadeSidor10);
	DDX_Text(pDX, IDC_MISSADESIDOR3, m_MissadeSidor3);
	DDX_Text(pDX, IDC_MISSADESIDOR4, m_MissadeSidor4);
	DDX_Text(pDX, IDC_MISSADESIDOR5, m_MissadeSidor5);
	DDX_Text(pDX, IDC_MISSADESIDOR6, m_MissadeSidor6);
	DDX_Text(pDX, IDC_MISSADESIDOR7, m_MissadeSidor7);
	DDX_Text(pDX, IDC_MISSADESIDOR8, m_MissadeSidor8);
	DDX_Text(pDX, IDC_MISSADESIDOR9, m_MissadeSidor9);
	DDX_Text(pDX, IDC_EDIT2, m_Instanser);
	DDX_Text(pDX, IDC_INLASTAODDS1, m_InlastaOdds1);
	DDX_Text(pDX, IDC_INLASTAODDS2, m_InlastaOdds2);
	DDX_Text(pDX, IDC_INLASTAODDS3, m_InlastaOdds3);
	DDX_Text(pDX, IDC_INLASTAODDS4, m_InlastaOdds4);
	DDX_Text(pDX, IDC_INLASTAODDS5, m_InlastaOdds5);
	DDX_Text(pDX, IDC_INLASTAODDS6, m_InlastaOdds6);
	DDX_Text(pDX, IDC_INLASTAODDS7, m_InlastaOdds7);
	DDX_Text(pDX, IDC_INLASTAODDS8, m_InlastaOdds8);
	DDX_Text(pDX, IDC_INLASTAODDS9, m_InlastaOdds9);
	DDX_Text(pDX, IDC_INLASTAODDS10, m_InlastaOdds10);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(COddsLas, CDialog)
	//{{AFX_MSG_MAP(COddsLas)
	ON_WM_SIZE()
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	//}}AFX_MSG_MAP

	ON_MESSAGE(WM_ODDSREAD, OnOddsRead)
	ON_MESSAGE(WM_ODDSFINISHED, OnOddsFinished)

END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// COddsLas message handlers
// S�kstr�ngar f�r scanf-funktioner
// OBS! M�len l�ses in som str�ngar eftersom F=10 f�rekommer 
// "width" skiljer sig mellan hockey och fotboll

#define SCANMALSTR		  "    <td class=\"mbr\" width=\"%d%%\" align=\"center\">%c - %c"
#define SCANODDSSTR		  "    <td class=\"mbr\" width=\"50%%\" align=\"right\">"


bool ScanSvenskaOdds(char *s1, char *s2, char *s3, char *so)
{
	char ch1, cb1, ch2, cb2, ch3='0', cb3='0'; // Tecken f�r antal m�l
	int width, h1,b1,h2,b2,h3,b3,h4,b4,todds=0, iodds,dodds;
	float odds;
	bool ret=false;

	if ((sscanf(s1,SCANMALSTR,&width,&ch1,&cb1) == 3) && (sscanf(s2,SCANMALSTR,&width,&ch2,&cb2)==3)  &&
		((Odds->m_speltyp==1 || Odds->m_speltyp==2)          || (sscanf(s3,SCANMALSTR,&width,&ch3,&cb3)==3)) &&  // Endast fotboll
		((sscanf(so,SCANODDSSTR "%d,%d",&iodds,&dodds) == 2) || 
		 (sscanf(so,SCANODDSSTR "%d %d,%d",&todds,&iodds,&dodds) == 3)))

	{
		h1 = (ch1=='F') ? 10 : ch1-'0';
		b1 = (cb1=='F') ? 10 : cb1-'0';
		h2 = (ch2=='F') ? 10 : ch2-'0';
		b2 = (cb2=='F') ? 10 : cb2-'0';
		h3 = (ch3=='F') ? 10 : ch3-'0';
		b3 = (cb3=='F') ? 10 : cb3-'0';

		odds = (float)todds*1000.0 + (float)iodds + (float)dodds/10.0;
		ret = true;

		// Uppdatera antal inl�sta odds
		if (!Odds->last[h1][b1][h2][b2][h3][b3][h4][b4])
			Odds->NumOdds ++;
		Odds->last[h1][b1][h2][b2][h3][b3][h4][b4] = true;


		// Ber�kna nominellt odds
		if (Odds->KB[h1][b1][h2][b2][h3][b3][h4][b4]!=NULL && Odds->KB[h1][b1][h2][b2][h3][b3][h4][b4]->NOdds > 0)
		{
			Odds->KB[h1][b1][h2][b2][h3][b3][h4][b4]->kvot = odds/Odds->KB[h1][b1][h2][b2][h3][b3][h4][b4]->NOdds;
			Odds->KB[h1][b1][h2][b2][h3][b3][h4][b4]->EjSpelad = false;
		}
	}
	return ret;
}

bool LasSvenskaOddsSida(int franp)
{
	char  buf[400], s1[400], s2[200], s3[200], so[200]; //, h1[100],b1[100];
	int  width;
	char h1,b1;
	bool traff=false;			// Tilldelan true om odds l�ses in 
	CStdioFile *pFile;
	CInternetSession m_Session;

				    //http://www.svenskaspel.se/pl.aspx?PageID=2544&round=2514&FranPos=0&mest=True
	sprintf(buf, "http://www.svenskaspel.se/pl.aspx?PageID=2544&round=%d&FranPos=%d&mest=True", Odds->m_matchid, franp); 
	pFile = m_Session.OpenURL(buf,1,INTERNET_FLAG_DONT_CACHE|INTERNET_FLAG_EXISTING_CONNECT|INTERNET_FLAG_TRANSFER_ASCII);

	while (pFile->ReadString( s1, sizeof(s1) )) 

		// Matchad f�rstastr�ng --> L�s in resterande
		if (sscanf(s1,SCANMALSTR,&width,&h1,&b1) == 3) {

			pFile->ReadString(s2, sizeof(s2));		// HTML-str�ng match 2
			// Fotboll eller Hocky med 3 matcher/perioder -->
			if (Odds->m_speltyp == 0 || Odds->m_speltyp == 8 || Odds->m_speltyp == 9) 
				pFile->ReadString(s3, sizeof(s3));	// HTML-str�ng match 3

			pFile->ReadString(so, sizeof(so));		// HTML-str�ng odds
		
			// Skanna str�ngar och tilldela odds
			if (ScanSvenskaOdds(s1, s2,s3, so))
				traff = true;

			// Nollst�ll str�ngar
			s1[0]='\0'; s2[0]='\0'; s2[0]='\0'; so[0]='\0'; 
		}

	pFile->Close();
	m_Session.Close();
	return traff;

}

UINT LasSvenskaOdds( LPVOID param )
{
	int MissadSida[1000];
	int franp;
	Odds->MissadeSidor = 0;;

	// L�s i samtliga odds
	for (franp=Odds->m_minsida; franp<Odds->m_maxsida; franp +=100)
	{

		// Oddsinl�sningf�nstret st�ngt (genom CANCEL) --> Avsluta
		if (!::IsWindowEnabled((HWND)param))
			return 0;

		// L�s odds-sida och markera eventuella missade sidor
		if (!LasSvenskaOddsSida(franp) && Odds->MissadeSidor < 1000)
			MissadSida[ Odds->MissadeSidor++ ] = franp;

		// Skicka message till dialogprogram f�r uppdatering av progress bar
		::PostMessage((HWND)param, WM_ODDSREAD,franp/100, 0);//(franp+100 >= Odds->m_maxsida));
	}	

	// Ta bort eventuella tomma sidor p� slutet
	franp -=100;
	while (Odds->MissadeSidor>0 && MissadSida[ Odds->MissadeSidor-1 ] == franp)
	{
			Odds->MissadeSidor --;
			franp -=100;
	}

	// L�s in missade sidor p� nytt
	int AntalSidor = Odds->MissadeSidor;
	for (int i=0; i<AntalSidor; i++)
	{
		// Oddsinl�sningf�nstret st�ngt (genom CANCEL) --> Avsluta
		if (!::IsWindowEnabled((HWND)param))
			return 0;

		if (LasSvenskaOddsSida( MissadSida[i]))
			Odds->MissadeSidor--;

		// Skicka message till dialogprogram f�r uppdatering av progress bar
		::PostMessage((HWND)param, WM_ODDSREAD,MissadSida[i]/100, 0);//(franp+100 >= Odds->m_maxsida));
	}
	
	
	// Skicka message till dialogprogram d� inl�sning �r klar
	::PostMessage((HWND)param, WM_ODDSFINISHED,0,0);
	return 0;
}
void COddsLas::Svenskinlasning()
{
	int AntalOdds, range;		

	if (Odds->m_OspeladeForvalt)
	   NollaOdds();

	AntalOdds = Odds->m_maxsida - Odds->m_minsida + 1;
	range = AntalOdds / m_Instanser;	
	
	// Avrunda upp�t till n�rmsta hundratal
	if ((range % 100) != 0)
		range = ((range/100) + 1) * 100;

	for (int i=0; i<10; i++)
	{
		if (i<m_Instanser)
		{
			*field[i].minsida = Odds->m_minsida + i*range;
			*field[i].maxsida = *field[i].minsida + range - 100;
		} 
		else {
			*field[i].minsida = 0;
			*field[i].maxsida = 0;
		}
	}
	UpdateData(FALSE);

	Odds->MissadeSidor = 0;
	m_progress.SetRange32(  *field[0].minsida,  *field[0].maxsida);
	m_progress2.SetRange32( *field[1].minsida,  *field[1].maxsida);
	m_progress3.SetRange32( *field[2].minsida,  *field[2].maxsida);
	m_progress4.SetRange32( *field[3].minsida,  *field[3].maxsida);
	m_progress5.SetRange32( *field[4].minsida,  *field[4].maxsida);
	m_progress6.SetRange32( *field[5].minsida,  *field[5].maxsida);
	m_progress7.SetRange32( *field[6].minsida,  *field[6].maxsida);
	m_progress8.SetRange32( *field[7].minsida,  *field[7].maxsida);
	m_progress9.SetRange32( *field[8].minsida,  *field[8].maxsida);
	m_progress10.SetRange32(*field[9].minsida,  *field[9].maxsida);

	// Starta tr�dinl�sning
	HWND hwnd = GetSafeHwnd();
//	Thread = AfxBeginThread(LasSvenskaOdds,hwnd);

	char OddsServStr[64], CmdStr[128];
	sprintf(OddsServStr,"Oddsinl�sning ID=%d", Odds->m_matchid);
	
	hMapFile = CreateFileMapping(INVALID_HANDLE_VALUE, NULL, PAGE_READWRITE, 0, sizeof( MEMFILETYPE), OddsServStr);
	pMap = (MEMFILETYPE *) MapViewOfFile(hMapFile, FILE_MAP_ALL_ACCESS, 0, 0, 0);

	// Startup OddsServer Process
	for (int i=0; i<m_Instanser; i++)
	{
		pMap->I[i].num			= 0;
		pMap->I[i].AntalOdds	= 0;
		pMap->I[i].MissadeSidor = 0;

		STARTUPINFO stInfo;
		PROCESS_INFORMATION prInfo;
		ZeroMemory( &stInfo, sizeof(stInfo) );
		stInfo.cb = sizeof(stInfo);
		stInfo.dwFlags=STARTF_USESHOWWINDOW;
		stInfo.wShowWindow=SW_MINIMIZE;

		sprintf(CmdStr, "OddsServer.exe %d %d %d %d %d", 
			Odds->m_matchid, Odds->m_speltyp, i, *field[i].minsida,  *field[i].maxsida);
	
		// Starta upp process
		// Om OddsServer inte finns i samma katalog 
		if (!CreateProcess(NULL, (LPSTR)(LPCSTR) CmdStr, NULL, NULL, TRUE, NORMAL_PRIORITY_CLASS, 
						NULL, NULL, &stInfo, &prInfo))
		{
			//	------> F�rs�k i debug-katalogen		
			sprintf(CmdStr, "../OddsServer/Debug/OddsServer.exe %d %d %d %d %d", 
						Odds->m_matchid, Odds->m_speltyp, i, *field[i].minsida,  *field[i].maxsida);

			CreateProcess(NULL, (LPSTR)(LPCSTR) CmdStr, NULL, NULL, TRUE, NORMAL_PRIORITY_CLASS, 
						NULL, NULL, &stInfo, &prInfo);

		}
	}

}
void COddsLas::SetOdds(int h1, int b1, int h2, int b2, int h3, int b3,int h4,int b4, float oddsval)
{
	// Uppdatera antal inl�sta odds
	if (!Odds->last[h1][b1][h2][b2][h3][b3][h4][b4])
		Odds->NumOdds ++;
	Odds->last[h1][b1][h2][b2][h3][b3][h4][b4] = true;


	// Ber�kna nominellt odds
	if (Odds->KB[h1][b1][h2][b2][h3][b3][h4][b4]!=NULL && Odds->KB[h1][b1][h2][b2][h3][b3][h4][b4]->NOdds > 0)
	{
		Odds->KB[h1][b1][h2][b2][h3][b3][h4][b4]->kvot = oddsval/Odds->KB[h1][b1][h2][b2][h3][b3][h4][b4]->NOdds;
		Odds->KB[h1][b1][h2][b2][h3][b3][h4][b4]->EjSpelad = false;
	}
}

// Inl�sning av en sida --> Uppdatera progress-bar och antal inl�sta odds
LONG COddsLas::OnOddsRead(WPARAM wParam, LPARAM lParam)
{
	int sida = (int) wParam;	// Inl�st sida
	int ins  = (int) lParam;	// Instans	

	UpdateData(true);						// F�nga ev. ikryssning
	
	m_AntalInlastaOdds = Odds->NumOdds;
	m_MissadeSidor = Odds->MissadeSidor;

	// Spel i sverige --> L�s data fr�n server
	if (Odds->m_speltyp <= 2  || Odds->m_speltyp == 8 || Odds->m_speltyp ==9 || Odds->m_speltyp ==10)
	{
		pMap->Upprepa = m_upprepa;	

		for (int j=0; j<pMap->I[ins].num; j++)
			SetOdds(pMap->I[ins].L[j].h1, pMap->I[ins].L[j].b1, pMap->I[ins].L[j].h2, pMap->I[ins].L[j].b2, 
					pMap->I[ins].L[j].h3, pMap->I[ins].L[j].b3,pMap->I[ins].L[j].h4, pMap->I[ins].L[j].b4, pMap->I[ins].L[j].odds);
		pMap->I[ins].num = 0;
	
		for (int i=0; i<m_Instanser; i++)
		{
			*field[i].MissadeSidor = pMap->I[i].MissadeSidor;
			*field[i].AntalOdds = pMap->I[i].AntalOdds;
		}
	}
	// Uppdatera f�lt
	if (ins == 0)
		m_progress.SetPos(sida + 1);
	else if (ins == 1)
		m_progress2.SetPos(sida + 1);
	else if (ins == 2)
		m_progress3.SetPos(sida + 1);
	else if (ins == 3)
		m_progress4.SetPos(sida + 1);
	else if (ins == 4)
		m_progress5.SetPos(sida + 1);
	else if (ins == 5)
		m_progress6.SetPos(sida + 1);
	else if (ins == 6)
		m_progress7.SetPos(sida + 1);
	else if (ins == 7)
		m_progress8.SetPos(sida + 1);
	else if (ins == 8)
		m_progress9.SetPos(sida + 1);
	else if (ins == 9)
		m_progress10.SetPos(sida + 1);

	UpdateData(false);					

	return 0;
}

// Inl�sning klar --> Ny inl�sning eller avsluta
LONG COddsLas::OnOddsFinished(WPARAM wParam, LPARAM lParam)
{
	UpdateData(true);
	Odds->m_OspeladeForvalt  = false;

	// Upprepa-ruta ikryssad  -->  Ny inl�sning
	if (m_upprepa)
		if (Odds->m_speltyp <= 2  || Odds->m_speltyp == 8 || Odds->m_speltyp == 9)
			; //Svenskinlasning();
		else
			Norskinlasning();


	else if (Odds->m_speltyp <= 2  || Odds->m_speltyp == 8 || Odds->m_speltyp == 9 || Odds->m_speltyp ==10)
	{
		// Kolla om alla instanser �r klara
		if (!pMap->Upprepa)
		{
			bool avsluta = true;
			for (int i=0; i<m_Instanser; i++)
				avsluta = avsluta && !pMap->I[i].Activ;
			// Ingen instans aktiv --> Avsluta
			if (avsluta)
				EndDialog(0);
		}
	}
	else			// --> Spel i norge
		EndDialog(0);

	return 0;
}

//void COddsLas::Finskinlasning(int startsida,int slutsida)
//{
//	CStdioFile *pFile;
//	CString sUrl;
//	char  sUrlOrg[300];
//	CInternetSession m_Session;
//	char str[64]; 
//	char bgcolor[10],cmatchid1,cmatchid2,cmatchid3,fpc1,fpc2,fpc3,fpc4,fpc5;
//	int h1,h2,h3,b1,b2,b3,iodds,iodds2,iodds3,dodds,franp,varv,antalInlastaodds;
//	float odds,fodds,f1,f2;
//	bool hittatodds;
//	m_progress.SetRange( 0, 100 );
//	m_progress.SetPos(0);
//	sprintf(sUrlOrg , "http://www.veikkaus.fi/odds/www/GetSysOdds?i=%d&H0=1&H1=1&H2=1&H3=1&H4=1&H5=1&H6=1&H7=1&H8=1&H9=1&V0=1&V1=1&V2=1&V3=1&V4=1&V5=1&V6=1&V7=1&V8=1&V9=1&I0=1&I1=1&I2=1&I3=1&I4=1&I5=1&I6=1&I7=1&I8=1&I9=1&W0=1&W1=1&W2=1&W3=1&W4=1&W5=1&W6=1&W7=1&W8=1&W9=1&J0=1&X0=1",
//		   Odds->m_matchid);
//	if(Odds->mh1*Odds->mb1*Odds->mh2*Odds->mb2 <= 5000)
//	{
//		sprintf(sUrlOrg , "http://www.veikkaus.fi/odds/www/GetSysOdds?i=%d&H0=1&H1=1&H2=1&H3=1",
//		   Odds->m_matchid);
//		sUrl = sUrlOrg;
//		if(Odds->mh1 > 3)
//			sUrl.Insert(500,"&H4=1");
//		if(Odds->mh1 > 4)
//			sUrl.Insert(500,"&H5=1");
//		if(Odds->mh1 > 5)
//			sUrl.Insert(500,"&H6=1");
//		if(Odds->mh1 > 6)
//			sUrl.Insert(500,"&H7=1");
//		if(Odds->mh1 > 7)
//			sUrl.Insert(500,"&H8=1");
//		if(Odds->mh1 > 8)
//			sUrl.Insert(500,"&H9=1");
//		///////////////////////////////
//		sUrl.Insert(500,"&V0=1&V1=1&V2=1&V3=1");
//		if(Odds->mb1 > 3)
//			sUrl.Insert(500,"&V4=1");
//		if(Odds->mb1 > 4)
//			sUrl.Insert(500,"&V5=1");
//		if(Odds->mb1 > 5)
//			sUrl.Insert(500,"&V6=1");
//		if(Odds->mb1 > 6)
//			sUrl.Insert(500,"&V7=1");
//		if(Odds->mb1 > 7)
//			sUrl.Insert(500,"&V8=1");
//		if(Odds->mb1 > 8)
//			sUrl.Insert(500,"&V9=1");
//		///////////////////////////////
//		sUrl.Insert(500,"&I0=1&I1=1&I2=1&I3=1");
//		if(Odds->mh2 > 3)
//			sUrl.Insert(500,"&I4=1");
//		if(Odds->mh2 > 4)
//			sUrl.Insert(500,"&I5=1");
//		if(Odds->mh2 > 5)
//			sUrl.Insert(500,"&I6=1");
//		if(Odds->mh2 > 6)
//			sUrl.Insert(500,"&I7=1");
//		if(Odds->mh2 > 7)
//			sUrl.Insert(500,"&I8=1");
//		if(Odds->mh2 > 8)
//			sUrl.Insert(500,"&I9=1");
//		///////////////////////////////
//		sUrl.Insert(500,"&W0=1&W1=1&W2=1&W3=1");
//		if(Odds->mb2 > 3)
//			sUrl.Insert(500,"&W4=1");
//		if(Odds->mb2 > 4)
//			sUrl.Insert(500,"&W5=1");
//		if(Odds->mb2 > 5)
//			sUrl.Insert(500,"&W6=1");
//		if(Odds->mb2 > 6)
//			sUrl.Insert(500,"&W7=1");
//		if(Odds->mb2 > 7)
//			sUrl.Insert(500,"&W8=1");
//		if(Odds->mb2 > 8)
//			sUrl.Insert(500,"&W9=1");
//		sUrl.Insert(500,"&J0=1");
//	}
//
//	 Finsk fotboll eller hockey med 3 matcher -->
//	if(Odds->m_speltyp == 3)
//	{
//		 if(Odds->m_speltyp == 0)
//		{
//			int ytterloop,innerloop,maxinner,totalavarv;
//			totalavarv = 0;
//			for(ytterloop = 0; ytterloop <9;ytterloop++)
//			{
//				 Replace J0=1 
//				if(Odds->mh1*Odds->mb1*Odds->mh2*Odds->mb2 <= 5000)
//				{
//					sUrl.SetAt(sUrl.GetLength()-3,ytterloop+48);
//				}
//				else
//				{
//					sUrl = sUrlOrg;
//					 sprintf(str, "J0=%c", ytterloop+48);
//					 sUrl.Replace("J0=1", str);
//					sUrl.SetAt(249,ytterloop+48);
//				}
//				if(ytterloop == 0)
//					maxinner = 8;
//				else if(ytterloop == 1)
//					maxinner = 7;
//				else if(ytterloop ==2)
//					maxinner = 7;
//				else if(ytterloop ==3)
//					maxinner = 7;
//				else if(ytterloop ==4)
//					maxinner = 5;
//				else if(ytterloop ==5)
//					maxinner = 4;
//				else if(ytterloop ==6)
//					maxinner = 3;
//				else if(ytterloop == 7)
//					maxinner = 3;
//				else if(ytterloop == 8)
//					maxinner = 0;
//				for(innerloop = 0;innerloop <=maxinner;innerloop++)
//				{
//					int inlasta;
//					inlasta = 0;
//					if(Odds->mh1*Odds->mb1*Odds->mh2*Odds->mb2 <= 5000)
//					{
//						CString sUrltmp;
//						sUrltmp = sUrl;
//						sUrltmp.Insert(500,"&X0=1");
//						sUrltmp.SetAt(sUrltmp.GetLength()-3,innerloop+48);
//						if(innerloop<maxinner)
//						{
//							sUrltmp.Insert(500,"&X0=1");
//							innerloop++;
//							sUrltmp.SetAt(sUrltmp.GetLength()-3,innerloop+48);
//						}
//						pFile = m_Session.OpenURL(sUrltmp, INTERNET_FLAG_TRANSFER_ASCII);
//					}
//					else
//					{
//						sUrl.SetAt(254,innerloop+48);
//						pFile = m_Session.OpenURL(sUrl, INTERNET_FLAG_TRANSFER_ASCII);
//					}
//					if (pFile==NULL)
//						return;
//					pFile->ReadString( buf, 399 );
//					do
//					{
//						
//						if(sscanf(buf,"%d - %d     %d - %d     %d - %d  	 %f,%f",&h1,&b1,&h2,&b2,&h3,&b3,&f1,&f2)>7)
//						{
//							odds = f1 + (f2/100);
//							inlasta++;
//							if (Odds->KB[h1][b1][h2][b2][h3][b3] != NULL)
//							{	
//								if(Odds->KB[h1][b1][h2][b2][h3][b3][0][0]->NOdds > 0)
//								{
//									Odds->KB[h1][b1][h2][b2][h3][b3][0][0]->kvot = odds/Odds->KB[h1][b1][h2][b2][h3][b3][0][0]->NOdds;
//								}
//							}
//						m_progress.SetPos(inlasta/10000);
//						}
//						else if(sscanf(buf,"%d - %d     %d - %d     %d - %d  	 %f",&h1,&b1,&h2,&b2,&h3,&b3,&odds)>5)
//						{
//							inlasta++;
//
//
//
//							if (Odds->KB[h1][b1][h2][b2][h3][b3][0][0] != NULL)
//							{	
//								Odds->KB[h1][b1][h2][b2][h3][b3][0][0]->EjSpelad = true;
//								Odds->KB[h1][b1][h2][b2][h3][b3][0][0]->kvot=0.0;
//
//				
//							}
//
//						}
//						
//					}
//					while(	pFile->ReadString( buf, 399 ));
//					totalavarv++;
//					if(Odds->mh1*Odds->mb1*Odds->mh2*Odds->mb2 <= 5000)
//						m_progress.SetPos(((totalavarv*100)/51)*2);
//					else
//					m_progress.SetPos((totalavarv*100)/51);
//					Invalidate(true);
//					
//				}
//				
//			}
//		}
//		m_Session.Close();
//		EndDialog(5);
//		return;
//	}
//
//	 Finsk hockey med 2 matcher -->
//	else if (Odds->m_speltyp == 4)
//	{
//        MessageBox("startar s�kning av sidan...");
//        sprintf(sUrlOrg,"http://www.veikkaus.fi/odds/www/GetSysOdds?i=%d&H0=1&H1=1&H2=1&H3=1&H4=1&H5=1&H6=1&H7=1&H8=1&H9=1&V0=1&V1=1&V2=1&V3=1&V4=1&V5=1&V6=1&V7=1&V8=1&V9=1&I0=1&I1=1&I2=1&I3=1&I4=1&I5=1&I6=1&I7=1&I8=1&I9=1&W0=1&W1=1&W2=1&W3=1&W4=1&W5=1&W6=1&W7=1&W8=1&W9=1",
//				   Odds->m_matchid);		
//		
//		pFile = m_Session.OpenURL(sUrlOrg);
//		MessageBox("Sidan hittad!");
//        if (pFile==NULL)
//				return;
//		pFile->ReadString( buf, 399 );
//		do
//		{
//						
//			if(sscanf(buf,"%d - %d     %d - %d     	 %f,%f",&h1,&b1,&h2,&b2,&f1,&f2)>5)
//			{
//				odds = f1 + (f2/100);
//							
//
//
//
//				if (Odds->KB[h1][b1][h2][b2][0][0] != NULL)
//				{	
//					if(Odds->KB[h1][b1][h2][b2][0][0]->NOdds > 0)
//					{
//							Odds->KB[h1][b1][h2][b2][0][0]->kvot = odds/Odds->KB[h1][b1][h2][b2][0][0]->NOdds;
//					}
//				}
//						
//			}
//			else if(sscanf(buf,"%d - %d     %d - %d    	 %f",&h1,&b1,&h2,&b2,&odds)>3)
//			{
//						
//
//				if (Odds->KB[h1][b1][h2][b2][0][0] != NULL)
//				{	
//					Odds->KB[h1][b1][h2][b2][0][0]->EjSpelad = true;
//					Odds->KB[h1][b1][h2][b2][0][0]->kvot=0.0;
//				
//				}
//			}
//						
//					}
//					while(	pFile->ReadString( buf, 399 ));
//					MessageBox("Oddsinl�sning klar!");
//		EndDialog(5);
//		return;
//	}
//
//	
//	
//	while(franp<=slutsida);
//	
//	Odds->antalInlastaodds = antalInlastaodds;
//	int antaluppfangadeodds;
//	antaluppfangadeodds = 0;
//	if(Odds->m_speltyp == 0)
//	{
//		for(int a1=0;a1<=10;a1++)
//			for(int a2=0;a2<=10;a2++)
//				for(int a3=0;a3<=10;a3++)
//					for(int a4=0;a4<=10;a4++)
//						for(int a5=0;a5<=10;a5++)
//							for(int a6=0;a6<=10;a6++)
//							{
//								if(Odds->KB[a1][a2][a3][a4][a5][a6]!=NULL)
//								{
//									if(Odds->KB[a1][a2][a3][a4][a5][a6]->kvot > 0.0005)
//										antaluppfangadeodds++;
//								}
//							}
//	}
//		MessageBox("klar!");
//	Odds->antaluppfangadeodds = antaluppfangadeodds;
//	Odds->antalmissadeinlastaodds = antalInlastaodds - antaluppfangadeodds;
//	m_Session.Close();
//		EndDialog(5);
//}

UINT LasUnibetOddsm2 ( LPVOID param )
{
	 int max_mh1, max_mb1, max_mh2, max_mb2, max_mh3;	
	 int MinMalGrp,MaxMalGrp;
	 char  sUrlOrgexpekt[300];
	 CInternetSession m_Session;
	CStdioFile *pFile;
	 CBombDlg BombDlg;
		MinMalGrp = BombDlg.m_MinMalGrp;
		MaxMalGrp = BombDlg.m_MaxMalGrp;
		max_mh1 = 4;
		max_mb1 = 4;
		max_mh2 = 6;
		max_mb2 = 6;
		max_mh3 = 6;
		sprintf(sUrlOrgexpekt,"http://www.expekt.com/supertotoProxy/ownodds.htm?coupon=%d&combp=11111111111111111111111000000000010000000000&filter=000000000&lang=sv",Odds->m_matchid);
	//	sprintf(sUrlOrgexpekt,"http://www.expekt.com/supertotoProxy/ownodds.htm?coupon=%d&combp=111111000001111110000011110000000100000000001000000000010000000000&filter=000000000&lang=sv", Odds->m_matchid);
	
		 for (int mh2 = 0; mh2<11; mh2++)
		 {
		
			if(mh2 == 9)
			{
				int a;
				a =0;
			}
			 if(mh2 > 0)
				sUrlOrgexpekt[88+mh2] = '0';
			 sUrlOrgexpekt[89+mh2] = '1';
			 for (int mb2 = 0; mb2<11; mb2++)
			 {
				  if(mb2 > 0)
					sUrlOrgexpekt[99+mb2] = '0';
				  if(mh2 > 0 && mb2 ==0)
					  sUrlOrgexpekt[110] = '0';
					sUrlOrgexpekt[100+mb2] = '1';
				 pFile = m_Session.OpenURL( sUrlOrgexpekt,1,INTERNET_FLAG_DONT_CACHE|INTERNET_FLAG_EXISTING_CONNECT|INTERNET_FLAG_TRANSFER_ASCII);
				//analysera inneh�llet
				 char buf1[100], buf2[100];


		char str[250];	
		int h1=-1, b1=-1, h2=-1, b2=-1, h3=-1, b3=-1,	h, b, oint,sret;
		int H1,B1,H2,B2,H3,B3,H4,B4;
		float ofloat, tempoddsodds;
		float Bel1, Bel2, Bel3, BelL, Bel, BelH;

		while ( pFile->ReadString( buf1, 99 ) )
		{
		
			if (sscanf(buf1,"\t\t\t\t<td class=\"mt_OddsResult\" align=\"center\">%d-%d", &h, &b)==2)
			{
				if (h1==-1)	
				{
					h1=h;
					b1=b;
				}
				else if (h2==-1)
				{
					h2=h;
					b2=b;
				}
			//	else 
			//	{
			//		h3=h;
			//		b3=b;
			//	}
			}

			if (h2 != -1 && sscanf(buf1,"%d,%f", &oint, &ofloat)==2)
			{
				tempoddsodds = oint*1000.0 + ofloat;
				if (Odds->KB[h1][b1][h2][b2][0][0][0][0] != NULL)
				{
					Odds->KB[h1][b1][h2][b2][0][0][0][0]->kvot = *(Odds->KvotJust) * tempoddsodds/Odds->KB[h1][b1][h2][b2][0][0][0][0]->NOdds;
					Odds->KB[h1][b1][h2][b2][0][0][0][0]->EjSpelad = false;
				}
				// R�kna upp antal inl�sta odds
				if (!Odds->last[h1][b1][h2][b2][0][0][0][0])
					Odds->NumOdds ++;
				Odds->last[h1][b1][h2][b2][0][0][0][0] = true;
				h1=-1; b1=-1; h2=-1; b2=-1; h3=-1; b3=-1;
			}

			if (h2 != -1 && sscanf(buf1,"%f", &ofloat)==1)
			{
				tempoddsodds = ofloat;
				if (Odds->KB[h1][b1][h2][b2][0][0][0][0] != NULL)
				{
					Odds->KB[h1][b1][h2][b2][0][0][0][0]->kvot = *(Odds->KvotJust) * tempoddsodds/Odds->KB[h1][b1][h2][b2][0][0][0][0]->NOdds;
					Odds->KB[h1][b1][h2][b2][0][0][0][0]->EjSpelad = false;
				}
				// R�kna upp antal inl�sta odds
				if (!Odds->last[h1][b1][h2][b2][0][0][0][0])
					Odds->NumOdds ++;
				Odds->last[h1][b1][h2][b2][0][0][0][0] = true;
				h1=-1; b1=-1; h2=-1; b2=-1; h3=-1; b3=-1;
			}

			if (h2 != -1 && strstr(buf1,"-&nbsp;") != NULL)
			{
				if (Odds->KB[h1][b1][h2][b2][0][0][0][0] != NULL)
					Odds->KB[h1][b1][h2][b2][0][0][0][0]->EjSpelad = true;

				// R�kna upp antal inl�sta odds
				if (!Odds->last[h1][b1][h2][b2][0][0][0][0])
					Odds->NumOdds ++;
				Odds->last[h1][b1][h2][b2][0][0][0][0] = true;
				h1=-1; b1=-1; h2=-1; b2=-1; h3=-1; b3=-1;
			}
			strcpy(buf2, buf1);
				//slut analysera inneh�llet
			 }
		}
	}
	::PostMessage((HWND)param, WM_ODDSFINISHED,0,0);
	return 0;
}

UINT LasUnibetOdds ( LPVOID param )
{
	 int max_mh1, max_mb1, max_mh2, max_mb2, max_mh3;	
	 int MinMalGrp,MaxMalGrp,antalvarv;
	 char  sUrlOrgexpekt[300];
	 CInternetSession m_Session;
	CStdioFile *pFile;
	 CBombDlg BombDlg;
		MinMalGrp = BombDlg.m_MinMalGrp;
		MaxMalGrp = BombDlg.m_MaxMalGrp;
		antalvarv = 0;
		max_mh1 = 4;
		max_mb1 = 4;
		max_mh2 = 6;
		max_mb2 = 6;
		max_mh3 = 6;
	//	sprintf(sUrlOrgexpekt,"http://www.expekt.com/supertotoProxy/ownodds.htm?coupon=3923&combp=111111000001111110000011110000000100000000001000000000010000000000&filter=000000000&lang=sv");
		sprintf(sUrlOrgexpekt,"http://www.expekt.com/supertotoProxy/ownodds.htm?coupon=%d&combp=111111000001111110000011110000000100000000001000000000010000000000&filter=000000000&lang=sv", Odds->m_matchid);
	
	    for (int mh2 = 0; mh2<2; mh2++)
		{
			if(mh2 == 1)
			{
				sUrlOrgexpekt[89] = '0';
				sUrlOrgexpekt[90] = '0';
				sUrlOrgexpekt[91] = '0';
				sUrlOrgexpekt[92] = '0';

				sUrlOrgexpekt[93] = '1';
				sUrlOrgexpekt[94] = '1';
				sUrlOrgexpekt[95] = '1';
				sUrlOrgexpekt[96] = '1';
				sUrlOrgexpekt[106] = '0';
			
			}
	      for (int mb2 = 0; mb2<7; mb2++)
		  {
			  sUrlOrgexpekt[117] = '0';
			   if(mb2 > 0)
			   {
				
				sUrlOrgexpekt[99+mb2] = '0';
			   }
			 sUrlOrgexpekt[100+mb2] = '1';
		      for (int mh3 = 0; mh3<7; mh3++)
			  {
				  sUrlOrgexpekt[128] = '0';
				  if(mh3 > 0)
				  {
					
					sUrlOrgexpekt[110+mh3] = '0';
				  }
				  sUrlOrgexpekt[111+mh3] = '1';
			       for (int mb3 = 0; mb3<7; mb3++)
					{
						if(mb3 > 0)
							sUrlOrgexpekt[121+mb3] = '0';
						sUrlOrgexpekt[122+mb3] = '1';

						 pFile = m_Session.OpenURL( sUrlOrgexpekt,1,INTERNET_FLAG_DONT_CACHE|INTERNET_FLAG_EXISTING_CONNECT|INTERNET_FLAG_TRANSFER_ASCII);
				//analysera inneh�llet
				 char buf1[100], buf2[100];


				char str[250];	
				int h1=-1, b1=-1, h2=-1, b2=-1, h3=-1, b3=-1,	h, b, oint,sret;
				int H1,B1,H2,B2,H3,B3,H4,B4,ickespelad;
				float ofloat, ofloat2,tempoddsodds;
				float Bel1, Bel2, Bel3, BelL, Bel, BelH;
				while ( pFile->ReadString( buf1, 99 ) )
		{
		
			if (sscanf(buf1,"\t\t\t\t<td class=\"mt_OddsResult\" align=\"center\">%d-%d", &h, &b)==2)
			{
				if (h1==-1)	
				{
					h1=h;
					b1=b;
				}
				else if (h2==-1)
				{
					h2=h;
					b2=b;
				}
				else 
				{
					h3=h;
					b3=b;
				}
			}
			else if(!ickespelad && sscanf(buf1,"\t\t\t<rs>%d-%d,%d-%d,%d-%d</rs>", &h1, &b1,&h2,&b2,&h3,&b3)==6)
			{
				//	tempoddsodds = oint*1000.0 + ofloat;
				if (Odds->KB[h1][b1][h2][b2][h3][b3][0][0] != NULL)
				{
					Odds->KB[h1][b1][h2][b2][h3][b3][0][0]->kvot = *(Odds->KvotJust) * tempoddsodds/Odds->KB[h1][b1][h2][b2][h3][b3][0][0]->NOdds;
					Odds->KB[h1][b1][h2][b2][h3][b3][0][0]->EjSpelad = false;
				}
				// R�kna upp antal inl�sta odds
				if (!Odds->last[h1][b1][h2][b2][h3][b3][0][0])
					Odds->NumOdds ++;
				Odds->last[h1][b1][h2][b2][h3][b3][0][0] = true;
				h1=-1; b1=-1; h2=-1; b2=-1; h3=-1; b3=-1;
			}
			else if(ickespelad && sscanf(buf1,"\t\t\t<rs>%d-%d,%d-%d,%d-%d</rs>", &h1, &b1,&h2,&b2,&h3,&b3)==6)
			{
				if (Odds->KB[h1][b1][h2][b2][h3][b3][0][0] != NULL)
					Odds->KB[h1][b1][h2][b2][h3][b3][0][0]->EjSpelad = true;

				//// R�kna upp antal inl�sta odds
				if (!Odds->last[h1][b1][h2][b2][h3][b3][0][0])
					Odds->NumOdds ++;
				Odds->last[h1][b1][h2][b2][h3][b3][0][0] = true;
				//h1=-1; b1=-1; h2=-1; b2=-1; h3=-1; b3=-1;
			}
		//	if (h2 != -1 && sscanf(buf1,"\t\t\t<odds>%f</odds>", &ofloat)==1)

			if (h2 != -1 && sscanf(buf1,"%d,%f", &oint, &ofloat)==2)
			{
				//	tempoddsodds = ofloat*1000.0 + ofloat2;
				tempoddsodds = oint*1000.0 + ofloat;
			//	tempoddsodds = oint + ofloat;
				ickespelad = false;
				if (Odds->KB[h1][b1][h2][b2][h3][b3][0][0] != NULL)
				{
					Odds->KB[h1][b1][h2][b2][h3][b3][0][0]->kvot = *(Odds->KvotJust) * tempoddsodds/Odds->KB[h1][b1][h2][b2][h3][b3][0][0]->NOdds;
					Odds->KB[h1][b1][h2][b2][h3][b3][0][0]->EjSpelad = false;
				}
				// R�kna upp antal inl�sta odds
				if (!Odds->last[h1][b1][h2][b2][h3][b3][0][0])
					Odds->NumOdds ++;
				Odds->last[h1][b1][h2][b2][h3][b3][0][0] = true;
				h1=-1; b1=-1; h2=-1; b2=-1; h3=-1; b3=-1;
			}

			else if (h2 != -1 && sscanf(buf1,"%f", &ofloat)==1)
			{
				tempoddsodds = ofloat;
				ickespelad = false;
				if (Odds->KB[h1][b1][h2][b2][h3][b3][0][0] != NULL)
				{
					Odds->KB[h1][b1][h2][b2][h3][b3][0][0]->kvot = *(Odds->KvotJust) * tempoddsodds/Odds->KB[h1][b1][h2][b2][h3][b3][0][0]->NOdds;
					Odds->KB[h1][b1][h2][b2][h3][b3][0][0]->EjSpelad = false;
				}
				// R�kna upp antal inl�sta odds
				if (!Odds->last[h1][b1][h2][b2][h3][b3][0][0])
					Odds->NumOdds ++;
				Odds->last[h1][b1][h2][b2][h3][b3][0][0] = true;
				h1=-1; b1=-1; h2=-1; b2=-1; h3=-1; b3=-1;
			}

			 

			

			if (h2 != -1 && strstr(buf1,"-&nbsp;") != NULL)
		//	else if(strstr(buf1,"<odds>-</odds>") != NULL)
			{
				ickespelad = true;
				if (Odds->KB[h1][b1][h2][b2][h3][b3][0][0] != NULL)
					Odds->KB[h1][b1][h2][b2][h3][b3][0][0]->EjSpelad = true;

				// R�kna upp antal inl�sta odds
				if (!Odds->last[h1][b1][h2][b2][h3][b3][0][0])
					Odds->NumOdds ++;
				Odds->last[h1][b1][h2][b2][h3][b3][0][0] = true;
				h1=-1; b1=-1; h2=-1; b2=-1; h3=-1; b3=-1;
			}
			strcpy(buf2, buf1);
				//slut analysera inneh�llet
			 }
				
					}
				   antalvarv++;
				::PostMessage((HWND)param, WM_ODDSREAD,antalvarv/20,0);

			  }
		  }
		}

		//Nu ska vi behandla odds med fler m�l.....////
		sprintf(sUrlOrgexpekt,"http://www.expekt.com/supertotoProxy/ownodds.htm?coupon=%d&combp=000000100001110000000011110000000111100000001110000000010000000000&filter=000000000&lang=sv", Odds->m_matchid);
		 for (int mb3 = 0; mb3<4; mb3++)
		{
				if(mb3 > 0)
					sUrlOrgexpekt[121+mb3] = '0';
				sUrlOrgexpekt[122+mb3] = '1';
				pFile = m_Session.OpenURL( sUrlOrgexpekt,1,INTERNET_FLAG_DONT_CACHE|INTERNET_FLAG_EXISTING_CONNECT|INTERNET_FLAG_TRANSFER_ASCII);
				//analysera inneh�llet
					 char buf1[100], buf2[100];


				char str[250];	
				int h1=-1, b1=-1, h2=-1, b2=-1, h3=-1, b3=-1,	h, b, oint,sret;
				int H1,B1,H2,B2,H3,B3,H4,B4,ickespelad;
				float ofloat, tempoddsodds;
				float Bel1, Bel2, Bel3, BelL, Bel, BelH;
				while ( pFile->ReadString( buf1, 99 ) )
		{
		
			if (sscanf(buf1,"\t\t\t\t<td class=\"mt_OddsResult\" align=\"center\">%d-%d", &h, &b)==2)
			{
				if (h1==-1)	
				{
					h1=h;
					b1=b;
				}
				else if (h2==-1)
				{
					h2=h;
					b2=b;
				}
				else 
				{
					h3=h;
					b3=b;
				}
			}
			else if(!ickespelad && sscanf(buf1,"\t\t\t<rs>%d-%d,%d-%d,%d-%d</rs>", &h1, &b1,&h2,&b2,&h3,&b3)==6)
			{
				//	tempoddsodds = oint*1000.0 + ofloat;
				if (Odds->KB[h1][b1][h2][b2][h3][b3][0][0] != NULL)
				{
					Odds->KB[h1][b1][h2][b2][h3][b3][0][0]->kvot = *(Odds->KvotJust) * tempoddsodds/Odds->KB[h1][b1][h2][b2][h3][b3][0][0]->NOdds;
					Odds->KB[h1][b1][h2][b2][h3][b3][0][0]->EjSpelad = false;
				}
				// R�kna upp antal inl�sta odds
				if (!Odds->last[h1][b1][h2][b2][h3][b3][0][0])
					Odds->NumOdds ++;
				Odds->last[h1][b1][h2][b2][h3][b3][0][0] = true;
				h1=-1; b1=-1; h2=-1; b2=-1; h3=-1; b3=-1;
			}
			else if(ickespelad && sscanf(buf1,"\t\t\t<rs>%d-%d,%d-%d,%d-%d</rs>", &h1, &b1,&h2,&b2,&h3,&b3)==6)
			{
				if (Odds->KB[h1][b1][h2][b2][h3][b3][0][0] != NULL)
					Odds->KB[h1][b1][h2][b2][h3][b3][0][0]->EjSpelad = true;

				//// R�kna upp antal inl�sta odds
				if (!Odds->last[h1][b1][h2][b2][h3][b3][0][0])
					Odds->NumOdds ++;
				Odds->last[h1][b1][h2][b2][h3][b3][0][0] = true;
				//h1=-1; b1=-1; h2=-1; b2=-1; h3=-1; b3=-1;
			}
		//	if (h2 != -1 && sscanf(buf1,"\t\t\t<odds>%f</odds>", &ofloat)==1)
			if (h2 != -1 && sscanf(buf1,"%d,%f", &oint, &ofloat)==2)
			{
				tempoddsodds = oint*1000.0 + ofloat;
			//	tempoddsodds = oint + ofloat;
				ickespelad = false;
				if (Odds->KB[h1][b1][h2][b2][h3][b3][0][0] != NULL)
				{
					Odds->KB[h1][b1][h2][b2][h3][b3][0][0]->kvot = *(Odds->KvotJust) * tempoddsodds/Odds->KB[h1][b1][h2][b2][h3][b3][0][0]->NOdds;
					Odds->KB[h1][b1][h2][b2][h3][b3][0][0]->EjSpelad = false;
				}
				// R�kna upp antal inl�sta odds
				if (!Odds->last[h1][b1][h2][b2][h3][b3][0][0])
					Odds->NumOdds ++;
				Odds->last[h1][b1][h2][b2][h3][b3][0][0] = true;
				h1=-1; b1=-1; h2=-1; b2=-1; h3=-1; b3=-1;
			}
			else if (h2 != -1 && sscanf(buf1,"%f", &ofloat)==1)
			{
				tempoddsodds = ofloat;
				ickespelad = false;
				if (Odds->KB[h1][b1][h2][b2][h3][b3][0][0] != NULL)
				{
					Odds->KB[h1][b1][h2][b2][h3][b3][0][0]->kvot = *(Odds->KvotJust) * tempoddsodds/Odds->KB[h1][b1][h2][b2][h3][b3][0][0]->NOdds;
					Odds->KB[h1][b1][h2][b2][h3][b3][0][0]->EjSpelad = false;
				}
				// R�kna upp antal inl�sta odds
				if (!Odds->last[h1][b1][h2][b2][h3][b3][0][0])
					Odds->NumOdds ++;
				Odds->last[h1][b1][h2][b2][h3][b3][0][0] = true;
				h1=-1; b1=-1; h2=-1; b2=-1; h3=-1; b3=-1;
			}
		//	else if (h2 != -1 && sscanf(buf1,"\t\t\t<odds>%d.%f</odds>", &oint, &ofloat)==2)
			

			

			if (h2 != -1 && strstr(buf1,"-&nbsp;") != NULL)
			//else if(strstr(buf1,"<odds>-</odds>") != NULL)
			{
				ickespelad = true;
				if (Odds->KB[h1][b1][h2][b2][h3][b3][0][0] != NULL)
					Odds->KB[h1][b1][h2][b2][h3][b3][0][0]->EjSpelad = true;

				// R�kna upp antal inl�sta odds
				if (!Odds->last[h1][b1][h2][b2][h3][b3][0][0])
					Odds->NumOdds ++;
				Odds->last[h1][b1][h2][b2][h3][b3][0][0] = true;
				h1=-1; b1=-1; h2=-1; b2=-1; h3=-1; b3=-1;
			}
			strcpy(buf2, buf1);
				//slut analysera inneh�llet
			 }
				//slut analysera inneh�llet
		//Slut odds med fler m�l.....
				 antalvarv++;
		 }

		 //Odds med 7 m�l i H1

		 sprintf(sUrlOrgexpekt,"http://www.expekt.com/supertotoProxy/ownodds.htm?coupon=%d&combp=000000010001110000000011110000000111100000001110000000010000000000&filter=000000000&lang=sv", Odds->m_matchid);
		 for (int mb3 = 0; mb3<4; mb3++)
		{
				if(mb3 > 0)
					sUrlOrgexpekt[121+mb3] = '0';
				sUrlOrgexpekt[122+mb3] = '1';
				pFile = m_Session.OpenURL( sUrlOrgexpekt,1,INTERNET_FLAG_DONT_CACHE|INTERNET_FLAG_EXISTING_CONNECT|INTERNET_FLAG_TRANSFER_ASCII);
				//analysera inneh�llet
					 char buf1[100], buf2[100];


				char str[250];	
				int h1=-1, b1=-1, h2=-1, b2=-1, h3=-1, b3=-1,	h, b, oint,sret;
				int H1,B1,H2,B2,H3,B3,H4,B4,ickespelad;
				float ofloat, tempoddsodds;
				float Bel1, Bel2, Bel3, BelL, Bel, BelH;
				while ( pFile->ReadString( buf1, 99 ) )
		{
		
			if (sscanf(buf1,"\t\t\t\t<td class=\"mt_OddsResult\" align=\"center\">%d-%d", &h, &b)==2)
			{
				if (h1==-1)	
				{
					h1=h;
					b1=b;
				}
				else if (h2==-1)
				{
					h2=h;
					b2=b;
				}
				else 
				{
					h3=h;
					b3=b;
				}
			}
			else if(!ickespelad && sscanf(buf1,"\t\t\t<rs>%d-%d,%d-%d,%d-%d</rs>", &h1, &b1,&h2,&b2,&h3,&b3)==6)
			{
				//	tempoddsodds = oint*1000.0 + ofloat;
				if (Odds->KB[h1][b1][h2][b2][h3][b3][0][0] != NULL)
				{
					Odds->KB[h1][b1][h2][b2][h3][b3][0][0]->kvot = *(Odds->KvotJust) * tempoddsodds/Odds->KB[h1][b1][h2][b2][h3][b3][0][0]->NOdds;
					Odds->KB[h1][b1][h2][b2][h3][b3][0][0]->EjSpelad = false;
				}
				// R�kna upp antal inl�sta odds
				if (!Odds->last[h1][b1][h2][b2][h3][b3][0][0])
					Odds->NumOdds ++;
				Odds->last[h1][b1][h2][b2][h3][b3][0][0] = true;
				h1=-1; b1=-1; h2=-1; b2=-1; h3=-1; b3=-1;
			}
			else if(ickespelad && sscanf(buf1,"\t\t\t<rs>%d-%d,%d-%d,%d-%d</rs>", &h1, &b1,&h2,&b2,&h3,&b3)==6)
			{
				if (Odds->KB[h1][b1][h2][b2][h3][b3][0][0] != NULL)
					Odds->KB[h1][b1][h2][b2][h3][b3][0][0]->EjSpelad = true;

				//// R�kna upp antal inl�sta odds
				if (!Odds->last[h1][b1][h2][b2][h3][b3][0][0])
					Odds->NumOdds ++;
				Odds->last[h1][b1][h2][b2][h3][b3][0][0] = true;
				//h1=-1; b1=-1; h2=-1; b2=-1; h3=-1; b3=-1;
			}
		//	if (h2 != -1 && sscanf(buf1,"\t\t\t<odds>%f</odds>", &ofloat)==1)
			if (h2 != -1 && sscanf(buf1,"%d,%f", &oint, &ofloat)==2)
			{
				tempoddsodds = oint*1000.0 + ofloat;
			//	tempoddsodds = oint + ofloat;
				ickespelad = false;
				if (Odds->KB[h1][b1][h2][b2][h3][b3][0][0] != NULL)
				{
					Odds->KB[h1][b1][h2][b2][h3][b3][0][0]->kvot = *(Odds->KvotJust) * tempoddsodds/Odds->KB[h1][b1][h2][b2][h3][b3][0][0]->NOdds;
					Odds->KB[h1][b1][h2][b2][h3][b3][0][0]->EjSpelad = false;
				}
				// R�kna upp antal inl�sta odds
				if (!Odds->last[h1][b1][h2][b2][h3][b3][0][0])
					Odds->NumOdds ++;
				Odds->last[h1][b1][h2][b2][h3][b3][0][0] = true;
				h1=-1; b1=-1; h2=-1; b2=-1; h3=-1; b3=-1;
			}
			else if (h2 != -1 && sscanf(buf1,"%f", &ofloat)==1)
			{
				tempoddsodds = ofloat;
				ickespelad = false;
				if (Odds->KB[h1][b1][h2][b2][h3][b3][0][0] != NULL)
				{
					Odds->KB[h1][b1][h2][b2][h3][b3][0][0]->kvot = *(Odds->KvotJust) * tempoddsodds/Odds->KB[h1][b1][h2][b2][h3][b3][0][0]->NOdds;
					Odds->KB[h1][b1][h2][b2][h3][b3][0][0]->EjSpelad = false;
				}
				// R�kna upp antal inl�sta odds
				if (!Odds->last[h1][b1][h2][b2][h3][b3][0][0])
					Odds->NumOdds ++;
				Odds->last[h1][b1][h2][b2][h3][b3][0][0] = true;
				h1=-1; b1=-1; h2=-1; b2=-1; h3=-1; b3=-1;
			}
		//	else if (h2 != -1 && sscanf(buf1,"\t\t\t<odds>%d.%f</odds>", &oint, &ofloat)==2)
			

			

			if (h2 != -1 && strstr(buf1,"-&nbsp;") != NULL)
			//else if(strstr(buf1,"<odds>-</odds>") != NULL)
			{
				ickespelad = true;
				if (Odds->KB[h1][b1][h2][b2][h3][b3][0][0] != NULL)
					Odds->KB[h1][b1][h2][b2][h3][b3][0][0]->EjSpelad = true;

				// R�kna upp antal inl�sta odds
				if (!Odds->last[h1][b1][h2][b2][h3][b3][0][0])
					Odds->NumOdds ++;
				Odds->last[h1][b1][h2][b2][h3][b3][0][0] = true;
				h1=-1; b1=-1; h2=-1; b2=-1; h3=-1; b3=-1;
			}
			strcpy(buf2, buf1);
				//slut analysera inneh�llet
			 }
				//slut analysera inneh�llet
		//Slut odds med fler m�l.....
				 antalvarv++;
		 }


		 //slut 7 m�l i H1

	::PostMessage((HWND)param, WM_ODDSFINISHED,0,0);
	return 0;
}

UINT LasNorskaOdds( LPVOID param )
//void COddsLas::Norskinlasning()
{
	CStdioFile *pFile, Logfile;

	char  sUrlOrg[300];
	CInternetSession m_Session;
	float odds;
	char buffer[1100];

     // MessageBox("startar s�kning av sidan...");
     //   sprintf(sUrlOrg,"http://www.norsk-tipping.no/wco?event=GETGAMEINFODETAIL&game_id=11&DrawID=257&segmentno=01&frameID=2&eventCount=3");
	 
 // sprintf(sUrlOrg,"https://www.norsk-tipping.no/gar/wco?event=getResultDetails&DrawID=1234&game_id=11&eventCount=3&segmentNo=01&");
 //   sprintf(sUrlOrg,"https://www.norsk-tipping.no/gar/wco?event=GETGAMEINFODETAIL&game_id=11&DrawID=3307&segmentNo=02&target=1&eventCount=3");	    
	sprintf(sUrlOrg,"https://www.norsk-tipping.no/api-oddsbomben/getOddsSummary.json?drawID=4755&segmentID=03");
/* int temposida,temposida2;
		temposida = Odds->m_matchid;
		temposida = ((Odds->m_matchid/100)*100);

		temposida2 = Odds->m_matchid - temposida;
		sUrlOrg[66] = (temposida/100)+48;

		temposida = ((temposida2/10)*10);
		sUrlOrg[67] = (temposida/10)+48;
		
		temposida = temposida2 - ((temposida2/10)*10);
		sUrlOrg[68] = (temposida+48);
		*/
	  /*  sprintf( &sUrlOrg[67+12],"%d", Odds->m_matchid); 
		sUrlOrg[71+12] = '&';*/

		sprintf( &sUrlOrg[71],"%d",Odds->m_matchid);
		sUrlOrg[75] = '&';
		int loopindex;
		loopindex = 1;
		
		for(int ytterloopen=loopindex;ytterloopen<=Odds->m_maxsida;ytterloopen++)
		{
			 
		if(ytterloopen<10)
		{
		//	sUrlOrg[105+1+1-12]=(ytterloopen+48);
			sUrlOrg[87]=(ytterloopen+48);
		}
		else
		{
			int th;
			th = ytterloopen - ((ytterloopen/10)*10);
		//	sUrlOrg[104+1+1-12]=((ytterloopen)/10)+48;
		//	sUrlOrg[105+1+1-12] = th+48;
			sUrlOrg[86]=((ytterloopen)/10)+48;
			sUrlOrg[87] = th+48;
		}
		
		//pFile = m_Session.OpenURL(sUrlOrg/*,1,INTERNET_FLAG_DONT_CACHE|INTERNET_FLAG_EXISTING_CONNECT|INTERNET_FLAG_TRANSFER_ASCII*/);
		// GB changed 04411024
		::Sleep(300);
//		pFile = m_Session.OpenURL(sUrlOrg,1,INTERNET_FLAG_DONT_CACHE|INTERNET_FLAG_EXISTING_CONNECT|INTERNET_FLAG_TRANSFER_ASCII);
//	pFile = m_Session.OpenURL(sUrlOrg,1,INTERNET_FLAG_EXISTING_CONNECT|INTERNET_FLAG_TRANSFER_ASCII|INTERNET_FLAG_PASSIVE);
	
		FILE *str;
		CStdioFile *pFile;
		long antal_simu,antal_utfall;
		char list[170];	// GB changed for mem.check  2008-10-11
	//	char list[17000000];
	//	char scantext[15];
		int aa,bb,cc,dd,ee,ff,index;

		//pFile = fopen_s( &str, "permu.txt", "r+" );
	
		char filnamn[12];
		sprintf(filnamn,"test%d.txt",ytterloopen);
	//	URLDownloadToFile( NULL,"https://www.norsk-tipping.no/api-oddsbomben/getOddsSummary.json?drawID=4755&segmentID=1","test1.txt", 0, NULL );
		
	//	URLDownloadToFile( NULL,"https://www.norsk-tipping.no/api-oddsbomben/getOddsSummary.json?drawID=4755&segmentID=2","test2.txt", 0, NULL );
		
		
		URLDownloadToFile( NULL,sUrlOrg,filnamn, 0, NULL );
//		URLDownloadToFile( NULL,sUrlOrg,"test.txt", 0, NULL );
//		fopen_s( &str, "permu.txt", "r+" );
		str = fopen( filnamn, "r+" );
//		fread( buffer, sizeof( char ), 1099, str);
	




		//////////////
		//GB 091013 , Dump file
		//int ret = Logfile.Open( "OddsLogg.txt", CFile::modeCreate| CFile::modeWrite | CFile::typeText );
		//
		//while (pFile->ReadString( buffer, 1099 ))
		//	Logfile.WriteString( buffer);
		//Logfile.Close();
		//pFile->Close();
		//ret = Logfile.Open( "OddsLogg.txt", CFile::modeRead | CFile::typeText );

		//pFile = &Logfile;
		// End GB change


		// Oddsinl�sningf�nstret st�ngt (genom CANCEL) --> Avsluta
		if (!::IsWindowEnabled((HWND)param))
			return 0;
		
		int nypos;
		//  Uppdatera progress-baren i dialogf�nstret
		// ::PostMessage((HWND)param, WM_ODDSREAD,ytterloopen,0);

      //  if (pFile==NULL)
		if(str==NULL)
				return 0;
		int status;
		status = 0;
		int funnaodds;
		funnaodds = 0;
		int bufferindex;
		bufferindex = 0;
		odds = 0;
		int slut;
		slut = 1;
		
		int tempodds[6][601];
		float tempoddsodds[601];

		for(int gg = 0;gg<=5;gg++)
		{
			for(int hh = 0;hh<=600;hh++)
				tempodds[gg][hh] = 0;
		}
		for(int yy = 0;yy<=600;yy++)
			tempoddsodds[yy] = 0.0;

		int ti1,ti2;
		ti1=0;ti2=1;
		// CStdioFile LoggFile("test.html", CFile::modeCreate | CFile::modeWrite);
		
	//	for(int bbb=0;bbb<10;bbb++)
		//	pFile->ReadString( buffer, 1099 );
		fread( buffer, sizeof( char ), 1099, str);
			 //   for(int ccc=0;ccc<100;ccc++)
			//	{
			//		pFile->ReadString( buffer, 999 );
			//		LoggFile.WriteString(buffer);
			//	}
			//	pFile->ReadString( buffer, 199999 );
			//	LoggFile.WriteString(buffer);
			//	LoggFile.Close();
		status = 0;
		do
		{

		/*	 	if(buffer[bufferindex] == 'n' && status ==0)
				status = 1;
			else if(buffer[bufferindex] =='e' && status == 1)
				status = 2;
			else if(buffer[bufferindex] !='e' && status == 1)
				status = 0;
			else if(buffer[bufferindex] =='w' && status == 2)
				status = 3;
			else if(buffer[bufferindex] == ' ' && status == 3)
				status = 4;*/
			if(buffer[bufferindex] == 's' && status == 0)
				status = 5;
			else if(buffer[bufferindex] == 'c' && status == 5)
				status = 6;
			else if(buffer[bufferindex] == 'o' && status == 6)
				status = 7;
			else if(buffer[bufferindex] == 'r' && status == 7)
				status = 8;
			else if(buffer[bufferindex] == 'e' && status == 8)
				status = 9;/**TH nytt*/
			else if(buffer[bufferindex] == 'T' && status == 9)
				status = 10;
			else if(buffer[bufferindex] == 'a' && status == 10)
				status = 11;
			else if(buffer[bufferindex] == 'b' && status == 11)
				status = 12;
			else if(buffer[bufferindex] == 'l' && status == 12)
				status = 13;
			else if(buffer[bufferindex] == 'e' && status == 13)
				status = 14;
			else if(buffer[bufferindex] == '[' && status == 14)
				status = 15;
			else if(buffer[bufferindex] == '[' && status == 15)
				status = 16;
			else if(buffer[bufferindex] == '[' && status == 16)
				status = 28;
//			else if(buffer[bufferindex] == '0' && status == 15)
//				status = 16;
			else if(buffer[bufferindex] == ']' && status == 16)
				status = 28;//nytt TH 20061108
			else if(buffer[bufferindex] == 'y' && status == 17)
				status = 18;
			else if(buffer[bufferindex] == 'n' && status == 18)
				status = 19;
			else if(buffer[bufferindex] == 'e' && status == 19)
				status = 20;
			else if(buffer[bufferindex] == 'w' && status == 20)
				status = 21;
			else if(buffer[bufferindex] == ' ' && status == 21)
				status = 22;
			else if(buffer[bufferindex] == 'A' && status == 22)
				status = 23;
			else if(buffer[bufferindex] == 'r' && status == 23)
				status = 24;
			else if(buffer[bufferindex] == 'r' && status == 24)
				status = 25;
			else if(buffer[bufferindex] == 'a' && status == 25)
				status = 26;
			else if(buffer[bufferindex] == 'y' && status == 26)
				status = 27;
			else if(buffer[bufferindex] == ']' && status == 27)/*th nytt*/
				status = 28;
			else if(buffer[bufferindex] >= '0' && buffer[bufferindex]<= '9' && status == 28)
				odds = 10*odds + (buffer[bufferindex]-48);
			else if(buffer[bufferindex] == ',' && status == 28)
			{
				tempodds[ti1][ti2] = odds;
				ti2++;
				odds = 0;
			}
			else if(buffer[bufferindex] == ']' && status == 28)/*TH nytt*/
			{
				tempodds[ti1][ti2] = odds;
				ti2++;
				odds = 0;
				status = 29;
			}
			else if(buffer[bufferindex] == '[' && status == 29)/*TH nytt*/
			{
				status = 30;
				ti1++;
				ti2 = 1;
				odds = 0;
			}
			else if(buffer[bufferindex] >= '0' && buffer[bufferindex]<= '9' && status == 30)
				odds = 10*odds + (buffer[bufferindex]-48);
			else if(buffer[bufferindex] == ',' && status == 30)
			{
				tempodds[ti1][ti2] = odds;
				ti2++;
				odds = 0;
			}
			else if(buffer[bufferindex] == ']' && status == 30)/*th nytt*/
			{
				tempodds[ti1][ti2] = odds;
				status = 31;
				ti1++;
				ti2 = 1;
				odds = 0;
			}
			else if(buffer[bufferindex] == '[' && status == 31)/*th nytt*/
				status = 33;
			else if(buffer[bufferindex] == ']' && status == 32)/*TH nytt* ScoreTable 1 ska nu l�sas*/
				status = 33;

			else if(buffer[bufferindex] >= '0' && buffer[bufferindex]<= '9' && status == 33)
				odds = 10*odds + (buffer[bufferindex]-48);
			else if(buffer[bufferindex] == ',' && status == 33)
			{
				tempodds[ti1][ti2] = odds;
				ti2++;
				odds = 0;
			}
			else if(buffer[bufferindex] == ']' && status == 33)/*th nytt*/
			{
				tempodds[ti1][ti2] = odds;
				status = 34;
			}
			else if(buffer[bufferindex] == '[' && status == 34)/*th nytt*/
			{
				status = 35;
				ti1++;
				ti2 = 1;
				odds = 0;
			}
			else if(buffer[bufferindex] >= '0' && buffer[bufferindex]<= '9' && status == 35)
				odds = 10*odds + (buffer[bufferindex]-48);
			else if(buffer[bufferindex] == ',' && status == 35)
			{
				tempodds[ti1][ti2] = odds;
				ti2++;
				odds = 0;
			}
			else if(buffer[bufferindex] == ']' && status == 35)/*th nytt*/
			{
				tempodds[ti1][ti2] = odds;
				status = 36;
				ti1++;
				ti2 = 1;
				odds = 0;
			}
			else if(buffer[bufferindex] == '[' && (status == 36 && Odds->m_speltyp==7))
				status = 42;
			else if(buffer[bufferindex] == '[' && status == 36)/*th nytt*/
				status = 38;
			else if(buffer[bufferindex] == '=' && status == 37)/*th nytt ScoreTable 3 ska nu l�sas*/
				status = 38;

			else if(buffer[bufferindex] >= '0' && buffer[bufferindex]<= '9' && status == 38)
				odds = 10*odds + (buffer[bufferindex]-48);
			else if(buffer[bufferindex] == ',' && status == 38)
			{
				tempodds[ti1][ti2] = odds;
				ti2++;
				odds = 0;
			}
			else if(buffer[bufferindex] == ']' && status == 38)/*th nytt*/
			{
				tempodds[ti1][ti2] = odds;
				status = 39;
			}
			else if(buffer[bufferindex] == '[' && status == 39)/*th nytt*/
			{
				status = 40;
				ti1++;
				ti2 = 1;
				odds = 0;
			}
			else if(buffer[bufferindex] >= '0' && buffer[bufferindex]<= '9' && status == 40)
				odds = 10*odds + (buffer[bufferindex]-48);
			else if(buffer[bufferindex] == ',' && status == 40)
			{
				tempodds[ti1][ti2] = odds;
				ti2++;
				odds = 0;
			}
			else if(buffer[bufferindex] == ']' && status == 40)/*th nytt*/
			{
				tempodds[ti1][ti2] = odds;
				status = 41;
				ti1++;
				ti2 = 1;
				odds = 0;
			}
			else if(buffer[bufferindex] == ':' && status == 41)/*th nytt*/
				status = 42;
			else if(buffer[bufferindex] >= '0' && buffer[bufferindex]<= '9' && status == 42)
				odds = 10*odds + (buffer[bufferindex]-48);
			else if(buffer[bufferindex] == '.' && status == 42)
			{
				tempoddsodds[ti2] = odds;
				status = 43;
			}
			else if(buffer[bufferindex] >= '0' && buffer[bufferindex]<= '9' && status == 43)
			{
				tempoddsodds[ti2] += 0.1*(buffer[bufferindex]-48);
				odds = 0;
				status = 44;
			}
			else if(buffer[bufferindex] >= '0' && buffer[bufferindex]<= '9' && status == 44)
			{
				tempoddsodds[ti2] += 0.01*(buffer[bufferindex]-48);
				odds = 0;
			}
			else if(buffer[bufferindex] == ',' && (status ==44))
			{
				status = 42;
				ti2++;
			}
			else if(buffer[bufferindex] == ']' && status == 44)
				status = 45;
			//	else
				//	status = 0;

		    bufferindex++;
			if(bufferindex == 1099)
			{
				bufferindex = 0;
			//	pFile->ReadString( buffer, 1099 );
				fread( buffer, sizeof( char ), 1099, str);
				int jj=0;
			}
			
						
		}
		while(status<45);

		int jj=0;
		

		for(int xxx=1;xxx<=600;xxx++)
		{
			int h1,b1,h2,b2,h3,b3;

			//**Tommy start 2003-10-10**//
			if(Odds->m_speltyp==6)
			{
				h1=tempodds[0][xxx];
				b1=tempodds[1][xxx];
				h2=tempodds[2][xxx];
				b2=tempodds[3][xxx];
				h3=tempodds[4][xxx];
				b3=tempodds[5][xxx];

				if(h1==0 && b1 == 0 && h2 ==0 && b2 ==0 && h3 ==0 && b3 ==0)
				{
					int a;
					a = 1;
				}

				//***Tommy slut 2003-10-10**//
				if ((tempodds[0][xxx] < 11) && (tempodds[1][xxx] < 11) && (tempodds[2][xxx] < 11) && (tempodds[3][xxx] < 11) &&
					(tempodds[4][xxx] < 11) && (tempodds[5][xxx] < 11) &&
					Odds->KB[tempodds[0][xxx]][tempodds[1][xxx]][tempodds[2][xxx]][tempodds[3][xxx]][tempodds[4][xxx]][tempodds[5][xxx]][0][0] != NULL)
				{	

					if(Odds->KB[tempodds[0][xxx]][tempodds[1][xxx]][tempodds[2][xxx]][tempodds[3][xxx]][tempodds[4][xxx]][tempodds[5][xxx]][0][0]->NOdds > 0 /* && (Odds->KB[tempodds[0][xxx]][tempodds[1][xxx]][tempodds[2][xxx]][tempodds[3][xxx]][tempodds[4][xxx]][tempodds[5][xxx]][0][0]->EjSpelad = false)*/)
					{
						Odds->KB[tempodds[0][xxx]][tempodds[1][xxx]][tempodds[2][xxx]][tempodds[3][xxx]][tempodds[4][xxx]][tempodds[5][xxx]][0][0]->kvot = *(Odds->KvotJust) * 
									tempoddsodds[xxx]/Odds->KB[tempodds[0][xxx]][tempodds[1][xxx]][tempodds[2][xxx]][tempodds[3][xxx]][tempodds[4][xxx]][tempodds[5][xxx]][0][0]->NOdds;
						Odds->KB[tempodds[0][xxx]][tempodds[1][xxx]][tempodds[2][xxx]][tempodds[3][xxx]][tempodds[4][xxx]][tempodds[5][xxx]][0][0]->EjSpelad = false;

						// R�kna upp antal inl�sta odds
						if (!Odds->last[tempodds[0][xxx]][tempodds[1][xxx]][tempodds[2][xxx]][tempodds[3][xxx]][tempodds[4][xxx]][tempodds[5][xxx]][0][0])
							Odds->NumOdds ++;
						Odds->last[tempodds[0][xxx]][tempodds[1][xxx]][tempodds[2][xxx]][tempodds[3][xxx]][tempodds[4][xxx]][tempodds[5][xxx]][0][0] = true;
						
						

					}
				}
				//***Tommy Start 2003-10-10**//
			}
			else if(Odds->m_speltyp==7)
			{
				//**Tommy Slut 2003-10-10**//
				if ((tempodds[0][xxx] < 11) && (tempodds[1][xxx] < 11) && (tempodds[2][xxx] < 11) && (tempodds[3][xxx] < 11) &&
				     Odds->KB[tempodds[0][xxx]][tempodds[1][xxx]][tempodds[2][xxx]][tempodds[3][xxx]][0][0][0][0] != NULL)
				{ 
					if(Odds->KB[tempodds[0][xxx]][tempodds[1][xxx]][tempodds[2][xxx]][tempodds[3][xxx]][0][0][0][0]->NOdds > 0)
					{
						Odds->KB[tempodds[0][xxx]][tempodds[1][xxx]][tempodds[2][xxx]][tempodds[3][xxx]][0][0][0][0]->kvot = *(Odds->KvotJust) * tempoddsodds[xxx]/Odds->KB[tempodds[0][xxx]][tempodds[1][xxx]][tempodds[2][xxx]][tempodds[3][xxx]][0][0][0][0]->NOdds;
						Odds->KB[tempodds[0][xxx]][tempodds[1][xxx]][tempodds[2][xxx]][tempodds[3][xxx]][0][0][0][0]->EjSpelad = false;
						// R�kna upp antal inl�sta odds
						if (!Odds->last[tempodds[0][xxx]][tempodds[1][xxx]][tempodds[2][xxx]][tempodds[3][xxx]][0][0][0][0])
							Odds->NumOdds ++;
						Odds->last[tempodds[0][xxx]][tempodds[1][xxx]][tempodds[2][xxx]][tempodds[3][xxx]][0][0][0][0] = true;
					}
				}
				//**Tommy Start 2003-10-10**//
			}
			//**Tommy Slut 2003-10-10**//
		}
		/*	segmentindex.Open( "segmentindex.txt", CFile::modeWrite    , 0 );
		sprintf(buf, "%d\n",DrawIDNo);
		segmentindex.WriteString(buf);
		sprintf(buf, "%d",ytterloopen);
		segmentindex.WriteString(buf);
		segmentindex.Close();
		char tbuffer1[10],tbuffer2[4],tbuffer3[4],tbuffer4[4],tbuffer5[4],tbuffer6[4];
		hemma1.SeekToEnd();
	
		for(int tt = 1; tt<601;tt++)
		{
			sprintf(tbuffer1,"%d\n",tempodds[0][tt]);
			hemma1.WriteString(tbuffer1);
			sprintf(tbuffer1,"%d\n",tempodds[1][tt]);
			hemma1.WriteString(tbuffer1);
			sprintf(tbuffer1,"%d\n",tempodds[2][tt]);
			hemma1.WriteString(tbuffer1);
			sprintf(tbuffer1,"%d\n",tempodds[3][tt]);
			hemma1.WriteString(tbuffer1);
			sprintf(tbuffer1,"%d\n",tempodds[4][tt]);
			hemma1.WriteString(tbuffer1);
			sprintf(tbuffer1,"%d\n",tempodds[5][tt]);
			hemma1.WriteString(tbuffer1);
			sprintf(tbuffer1,"%f\n",tempoddsodds[tt]);
			hemma1.WriteString(tbuffer1);
		
		}*/
		//pFile->Close();
		fclose(str);

		//  Uppdatera progress-baren i dialogf�nstret
		::PostMessage((HWND)param, WM_ODDSREAD,ytterloopen,0);
		}
	//	Odds->Save("test.txt");
	// hemma1.Close();
	::PostMessage((HWND)param, WM_ODDSFINISHED,0,0);
	return 0;
}



void COddsLas::NollaOdds()
{
   Odds->NumOdds = 0;	// Nollst�ll antal inl�sta odds
   for(int t1 = 0;t1<MAXRES;t1++)
	 for(int t2 = 0;t2<MAXRES;t2++)
		for(int t3 = 0;t3<MAXRES;t3++)
    		for(int t4 = 0;t4<MAXRES;t4++)
				for(int t5 = 0;t5<MAXRES;t5++)
					for(int t6 = 0;t6<MAXRES;t6++)
						for(int t7 = 0;t7<MAXRES4;t7++)
							for(int t8 = 0;t8<MAXRES4;t8++)
					{
						if (Odds->KB[t1][t2][t3][t4][t5][t6][t7][t8] != NULL)
						{
							Odds->KB[t1][t2][t3][t4][t5][t6][t7][t8]->EjSpelad = true;
							Odds->KB[t1][t2][t3][t4][t5][t6][t7][t8]->kvot=0.0;
							Odds->last[t1][t2][t3][t4][t5][t6][t7][t8] = false;
							
						}
			
					}
}
void COddsLas::UnibetInlasning()
{
	if (Odds->m_OspeladeForvalt)
	   NollaOdds();

	m_progress.SetRange( 0, Odds->m_maxsida);
	// Starta tr�dinl�sning
	HWND hwnd = GetSafeHwnd();
	Thread = AfxBeginThread(LasUnibetOdds,hwnd);
	//EndDialog(5);

}

void COddsLas::UnibetInlasningm2()
{
	if (Odds->m_OspeladeForvalt)
	   NollaOdds();

	m_progress.SetRange( 0, Odds->m_maxsida);
	// Starta tr�dinl�sning
	HWND hwnd = GetSafeHwnd();
	Thread = AfxBeginThread(LasUnibetOddsm2,hwnd);
	//EndDialog(5);

}

void COddsLas::Norskinlasning()
{
	if (Odds->m_OspeladeForvalt)
	   NollaOdds();

	m_progress.SetRange( 0, Odds->m_maxsida);
	// Starta tr�dinl�sning
	HWND hwnd = GetSafeHwnd();
	Thread = AfxBeginThread(LasNorskaOdds,hwnd);
	//EndDialog(5);

}
BOOL COddsLas::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	// �ndra rubriktext p� f�nster s� att Odds-servrarna kan hitta det
	// (det skall vara m�jligt att k�ra tv� bomb-program paralellt
	char str[64];
	sprintf(str,"Oddsinl�sning ID=%d", Odds->m_matchid);
	SetWindowText(str);


	Thread = NULL;
	m_AntalInlastaOdds = Odds->NumOdds;
	m_MissadeSidor = Odds->MissadeSidor;
	m_upprepa = Odds->m_UpprepaForvalt;
	m_Instanser = Odds->m_Instanser;

	field[0].minsida = &m_minsida1;		field[0].maxsida = &m_maxsida1;		field[0].MissadeSidor = &m_MissadeSidor;
	field[1].minsida = &m_minsida2;		field[1].maxsida = &m_maxsida2;		field[1].MissadeSidor = &m_MissadeSidor2;
	field[2].minsida = &m_minsida3;		field[2].maxsida = &m_maxsida3;		field[2].MissadeSidor = &m_MissadeSidor3;
	field[3].minsida = &m_minsida4;		field[3].maxsida = &m_maxsida4;		field[3].MissadeSidor = &m_MissadeSidor4;
	field[4].minsida = &m_minsida5;		field[4].maxsida = &m_maxsida5;		field[4].MissadeSidor = &m_MissadeSidor5;
	field[5].minsida = &m_minsida6;		field[5].maxsida = &m_maxsida6;		field[5].MissadeSidor = &m_MissadeSidor6;
	field[6].minsida = &m_minsida7;		field[6].maxsida = &m_maxsida7;		field[6].MissadeSidor = &m_MissadeSidor7;
	field[7].minsida = &m_minsida8;		field[7].maxsida = &m_maxsida8;		field[7].MissadeSidor = &m_MissadeSidor8;
	field[8].minsida = &m_minsida9;		field[8].maxsida = &m_maxsida9;		field[8].MissadeSidor = &m_MissadeSidor9;
	field[9].minsida = &m_minsida10;	field[9].maxsida = &m_maxsida10;	field[9].MissadeSidor = &m_MissadeSidor10;

	field[0].AntalOdds = &m_InlastaOdds1;
	field[1].AntalOdds = &m_InlastaOdds2;
	field[2].AntalOdds = &m_InlastaOdds3;
	field[3].AntalOdds = &m_InlastaOdds4;
	field[4].AntalOdds = &m_InlastaOdds5;
	field[5].AntalOdds = &m_InlastaOdds6;
	field[6].AntalOdds = &m_InlastaOdds7;
	field[7].AntalOdds = &m_InlastaOdds8;
	field[8].AntalOdds = &m_InlastaOdds9;
	field[9].AntalOdds = &m_InlastaOdds10;

	UpdateData(false);
	ShowWindow(SW_SHOW);
	RedrawWindow();
	if  (Odds->m_speltyp <= 2 || Odds->m_speltyp == 8 || Odds->m_speltyp == 9 || Odds->m_speltyp ==10)
		Svenskinlasning();
	else if (Odds->m_speltyp == 12)
		UnibetInlasning();
	else if (Odds->m_speltyp == 13 || Odds->m_speltyp == 14)
		UnibetInlasningm2();
	else if  (Odds->m_speltyp >= 6)
		Norskinlasning();

	else
		; //Finskinlasning(0,0);
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void COddsLas::OnCancel() 
{
	// TODO: Add extra cleanup here
	
	CDialog::OnCancel();
	int treadexit = ::TerminateThread(Thread, 0);
}


void COddsLas::OnOK() 
{
	// Don't finnish on <Return>
}

void COddsLas::OnButton1() 
{
	// Create MapFile for odds reading
	TCHAR str1[100], str2[100];
	::GetClassName( GetSafeHwnd(), str1, 100);
	::GetWindowText( GetSafeHwnd(), str2, 100);
	MessageBox(str1, str2);	

	char OddsServStr[64];
	sprintf(OddsServStr,"Oddsinl�sning ID=%d", Odds->m_matchid);
	
	hMapFile = CreateFileMapping(INVALID_HANDLE_VALUE, NULL, PAGE_READWRITE, 0, sizeof( MEMFILETYPE), OddsServStr);
	pMap = (MEMFILETYPE *) MapViewOfFile(hMapFile, FILE_MAP_ALL_ACCESS, 0, 0, 0);
	pMap->I[0].num = 0;

	// Startup OddsServer Process
	/* STARTUPINFO stInfo;
	PROCESS_INFORMATION prInfo;
	BOOL bResult;
	ZeroMemory( &stInfo, sizeof(stInfo) );
	stInfo.cb = sizeof(stInfo);
	stInfo.dwFlags=STARTF_USESHOWWINDOW;
	stInfo.wShowWindow=SW_MINIMIZE;

	bResult = CreateProcess(NULL,
                         (LPSTR)(LPCSTR)"../OddsServer/Debug/OddsServer.exe",
                         NULL, NULL, TRUE, NORMAL_PRIORITY_CLASS, NULL, NULL, &stInfo, &prInfo);
	BOOL res=bResult;
	*/

}
