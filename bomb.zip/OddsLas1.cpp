// OddsLas.cpp : implementation file
//

#include "stdafx.h"
#include "bomb.h"
#include "OddsLas.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COddsLas dialog


COddsLas::COddsLas(CWnd* pParent /*=NULL*/)
	: CDialog(COddsLas::IDD, pParent)
{
	//{{AFX_DATA_INIT(COddsLas)
	m_AntalInlastaOdds = 0;
	m_upprepa = FALSE;
	m_MissadeSidor = 0;
	//}}AFX_DATA_INIT
}


void COddsLas::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(COddsLas)
	DDX_Control(pDX, IDC_PROGRESS1, m_progress);
	DDX_Text(pDX, IDC_EDIT1, m_AntalInlastaOdds);
	DDX_Check(pDX, IDC_CHECK_UPPREPA, m_upprepa);
	DDX_Text(pDX, IDC_EDIT2, m_MissadeSidor);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(COddsLas, CDialog)
	//{{AFX_MSG_MAP(COddsLas)
	ON_WM_SIZE()
	//}}AFX_MSG_MAP

	ON_MESSAGE(WM_ODDSREAD, OnOddsRead)
	ON_MESSAGE(WM_ODDSFINISHED, OnOddsFinished)

END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// COddsLas message handlers
// S�kstr�ngar f�r scanf-funktioner
// OBS! M�len l�ses in som str�ngar eftersom F=10 f�rekommer 
// "width" skiljer sig mellan hockey och fotboll

#define SCANMALSTR		  "    <td class=\"mbr\" width=\"%d%%\" align=\"center\">%c - %c"
#define SCANODDSSTR		  "    <td class=\"mbr\" width=\"50%%\" align=\"right\">"


bool ScanSvenskaOdds(char *s1, char *s2, char *s3, char *so)
{
	char ch1, cb1, ch2, cb2, ch3='0', cb3='0'; // Tecken f�r antal m�l
	int width, h1,b1,h2,b2,h3,b3,todds=0, iodds,dodds;
	float odds;
	bool ret=false;

	if ((sscanf(s1,SCANMALSTR,&width,&ch1,&cb1) == 3) && (sscanf(s2,SCANMALSTR,&width,&ch2,&cb2)==3)  &&
		((Odds->m_speltyp==1 || Odds->m_speltyp==2)          || (sscanf(s3,SCANMALSTR,&width,&ch3,&cb3)==3)) &&  // Endast fotboll
		((sscanf(so,SCANODDSSTR "%d,%d",&iodds,&dodds) == 2) || 
		 (sscanf(so,SCANODDSSTR "%d %d,%d",&todds,&iodds,&dodds) == 3)))

	{
		h1 = (ch1=='F') ? 10 : ch1-'0';
		b1 = (cb1=='F') ? 10 : cb1-'0';
		h2 = (ch2=='F') ? 10 : ch2-'0';
		b2 = (cb2=='F') ? 10 : cb2-'0';
		h3 = (ch3=='F') ? 10 : ch3-'0';
		b3 = (cb3=='F') ? 10 : cb3-'0';

		odds = (float)todds*1000.0 + (float)iodds + (float)dodds/10.0;
		ret = true;

		// Uppdatera antal inl�sta odds
		if (!Odds->last[h1][b1][h2][b2][h3][b3])
			Odds->NumOdds ++;
		Odds->last[h1][b1][h2][b2][h3][b3] = true;


		// Ber�kna nominellt odds
		if (Odds->KB[h1][b1][h2][b2][h3][b3]!=NULL && Odds->KB[h1][b1][h2][b2][h3][b3]->NOdds > 0)
		{
			Odds->KB[h1][b1][h2][b2][h3][b3]->kvot = odds/Odds->KB[h1][b1][h2][b2][h3][b3]->NOdds;
			Odds->KB[h1][b1][h2][b2][h3][b3]->EjSpelad = false;
		}
	}
	return ret;
}

bool LasSvenskaOddsSida(int franp)
{
	char  buf[400], s1[400], s2[200], s3[200], so[200]; //, h1[100],b1[100];
	int  width;
	char h1,b1;
	bool traff=false;			// Tilldelan true om odds l�ses in 
	CStdioFile *pFile;
	CInternetSession m_Session;

				    //http://www.svenskaspel.se/pl.aspx?PageID=2544&round=2514&FranPos=0&mest=True
	sprintf(buf, "http://www.svenskaspel.se/pl.aspx?PageID=2544&round=%d&FranPos=%d&mest=True", Odds->m_matchid, franp); 
	pFile = m_Session.OpenURL(buf,1,INTERNET_FLAG_DONT_CACHE|INTERNET_FLAG_EXISTING_CONNECT|INTERNET_FLAG_TRANSFER_ASCII);

	while (pFile->ReadString( s1, sizeof(s1) )) 

		// Matchad f�rstastr�ng --> L�s in resterande
		if (sscanf(s1,SCANMALSTR,&width,&h1,&b1) == 3) {

			pFile->ReadString(s2, sizeof(s2));		// HTML-str�ng match 2
			// Fotboll eller Hocky med 3 matcher -->
			if (Odds->m_speltyp == 0 || Odds->m_speltyp == 8) 
				pFile->ReadString(s3, sizeof(s3));	// HTML-str�ng match 3

			pFile->ReadString(so, sizeof(so));		// HTML-str�ng odds
		
			// Skanna str�ngar och tilldela odds
			if (ScanSvenskaOdds(s1, s2,s3, so))
				traff = true;

			// Nollst�ll str�ngar
			s1[0]='\0'; s2[0]='\0'; s2[0]='\0'; so[0]='\0'; 
		}

	pFile->Close();
	m_Session.Close();
	return traff;

}

UINT LasSvenskaOdds( LPVOID param )
{
	int MissadSida[1000];
	Odds->MissadeSidor = 0;;

	// L�s i samtliga odds
	for (int franp=1; franp<Odds->m_maxsida; franp +=100)
	{
		// Oddsinl�sningf�nstret st�ngt (genom CANCEL) --> Avsluta
		if (!::IsWindowEnabled((HWND)param))
			return 0;

		// L�s odds-sida och markera eventuella missade sidor
		if (!LasSvenskaOddsSida(franp) && Odds->MissadeSidor < 1000)
			MissadSida[ Odds->MissadeSidor++ ] = franp;

		// Skicka message till dialogprogram f�r uppdatering av progress bar
		::PostMessage((HWND)param, WM_ODDSREAD,franp/100, 0);//(franp+100 >= Odds->m_maxsida));
	}	

	// Ta bort eventuella tomma sidor p� slutet
	franp -=100;
	while (Odds->MissadeSidor>0 && MissadSida[ Odds->MissadeSidor-1 ] == franp)
	{
			Odds->MissadeSidor --;
			franp -=100;
	}

	// L�s in missade sidor p� nytt
	int AntalSidor = Odds->MissadeSidor;
	for (int i=0; i<AntalSidor; i++)
	{
		// Oddsinl�sningf�nstret st�ngt (genom CANCEL) --> Avsluta
		if (!::IsWindowEnabled((HWND)param))
			return 0;

		if (LasSvenskaOddsSida( MissadSida[i]))
			Odds->MissadeSidor--;

		// Skicka message till dialogprogram f�r uppdatering av progress bar
		::PostMessage((HWND)param, WM_ODDSREAD,MissadSida[i]/100, 0);//(franp+100 >= Odds->m_maxsida));
	}
	
	
	// Skicka message till dialogprogram d� inl�sning �r klar
	::PostMessage((HWND)param, WM_ODDSFINISHED,0,0);
	return 0;
}
void COddsLas::Svenskinlasning()
{

	if (Odds->m_OspeladeForvalt)
	   NollaOdds();
	Odds->MissadeSidor = 0;
	m_progress.SetRange( 0, Odds->m_maxsida/100);;
	// Starta tr�dinl�sning
	HWND hwnd = GetSafeHwnd();
	Thread = AfxBeginThread(LasSvenskaOdds,hwnd);

}
// Inl�sning av en sida --> Uppdatera progress-bar och antal inl�sta odds
LONG COddsLas::OnOddsRead(WPARAM wParam, LPARAM lParam)
{
	UpdateData(true);						// F�nga ev. ikryssning
	m_AntalInlastaOdds = Odds->NumOdds;
	m_MissadeSidor = Odds->MissadeSidor;
	m_progress.SetPos((int) wParam + 1);
	UpdateData(false);					

	return 0;
}

// Inl�sning klar --> Ny inl�sning eller avsluta
LONG COddsLas::OnOddsFinished(WPARAM wParam, LPARAM lParam)
{
	UpdateData(true);
	Odds->m_OspeladeForvalt  = false;

	// Upprepa-ruta ikryssad  -->  Ny inl�sning
	if (m_upprepa)
		if (Odds->m_speltyp <= 2  || Odds->m_speltyp == 8)
			Svenskinlasning();
		else
			Norskinlasning();

	else 	//   --> Avsluta
		EndDialog(5);

	return 0;
}

void COddsLas::Finskinlasning(int startsida,int slutsida)
{
	CStdioFile *pFile;
	CString sUrl;
	char  sUrlOrg[300];
	CInternetSession m_Session;
	char str[64]; 
	char bgcolor[10],cmatchid1,cmatchid2,cmatchid3,fpc1,fpc2,fpc3,fpc4,fpc5;
	int h1,h2,h3,b1,b2,b3,iodds,iodds2,iodds3,dodds,franp,varv,antalInlastaodds;
	float odds,fodds,f1,f2;
	bool hittatodds;
//	m_progress.SetRange( 0, 100 );
//	m_progress.SetPos(0);
	sprintf(sUrlOrg , "http://www.veikkaus.fi/odds/www/GetSysOdds?i=%d&H0=1&H1=1&H2=1&H3=1&H4=1&H5=1&H6=1&H7=1&H8=1&H9=1&V0=1&V1=1&V2=1&V3=1&V4=1&V5=1&V6=1&V7=1&V8=1&V9=1&I0=1&I1=1&I2=1&I3=1&I4=1&I5=1&I6=1&I7=1&I8=1&I9=1&W0=1&W1=1&W2=1&W3=1&W4=1&W5=1&W6=1&W7=1&W8=1&W9=1&J0=1&X0=1",
		   Odds->m_matchid);
	if(Odds->mh1*Odds->mb1*Odds->mh2*Odds->mb2 <= 5000)
	{
		sprintf(sUrlOrg , "http://www.veikkaus.fi/odds/www/GetSysOdds?i=%d&H0=1&H1=1&H2=1&H3=1",
		   Odds->m_matchid);
		sUrl = sUrlOrg;
		if(Odds->mh1 > 3)
			sUrl.Insert(500,"&H4=1");
		if(Odds->mh1 > 4)
			sUrl.Insert(500,"&H5=1");
		if(Odds->mh1 > 5)
			sUrl.Insert(500,"&H6=1");
		if(Odds->mh1 > 6)
			sUrl.Insert(500,"&H7=1");
		if(Odds->mh1 > 7)
			sUrl.Insert(500,"&H8=1");
		if(Odds->mh1 > 8)
			sUrl.Insert(500,"&H9=1");
		/////////////////////////////////
		sUrl.Insert(500,"&V0=1&V1=1&V2=1&V3=1");
		if(Odds->mb1 > 3)
			sUrl.Insert(500,"&V4=1");
		if(Odds->mb1 > 4)
			sUrl.Insert(500,"&V5=1");
		if(Odds->mb1 > 5)
			sUrl.Insert(500,"&V6=1");
		if(Odds->mb1 > 6)
			sUrl.Insert(500,"&V7=1");
		if(Odds->mb1 > 7)
			sUrl.Insert(500,"&V8=1");
		if(Odds->mb1 > 8)
			sUrl.Insert(500,"&V9=1");
		/////////////////////////////////
		sUrl.Insert(500,"&I0=1&I1=1&I2=1&I3=1");
		if(Odds->mh2 > 3)
			sUrl.Insert(500,"&I4=1");
		if(Odds->mh2 > 4)
			sUrl.Insert(500,"&I5=1");
		if(Odds->mh2 > 5)
			sUrl.Insert(500,"&I6=1");
		if(Odds->mh2 > 6)
			sUrl.Insert(500,"&I7=1");
		if(Odds->mh2 > 7)
			sUrl.Insert(500,"&I8=1");
		if(Odds->mh2 > 8)
			sUrl.Insert(500,"&I9=1");
		/////////////////////////////////
		sUrl.Insert(500,"&W0=1&W1=1&W2=1&W3=1");
		if(Odds->mb2 > 3)
			sUrl.Insert(500,"&W4=1");
		if(Odds->mb2 > 4)
			sUrl.Insert(500,"&W5=1");
		if(Odds->mb2 > 5)
			sUrl.Insert(500,"&W6=1");
		if(Odds->mb2 > 6)
			sUrl.Insert(500,"&W7=1");
		if(Odds->mb2 > 7)
			sUrl.Insert(500,"&W8=1");
		if(Odds->mb2 > 8)
			sUrl.Insert(500,"&W9=1");
		sUrl.Insert(500,"&J0=1");
	}

	// Finsk fotboll eller hockey med 3 matcher -->
	if(Odds->m_speltyp == 3)
	{
		// if(Odds->m_speltyp == 0)
		{
			int ytterloop,innerloop,maxinner,totalavarv;
			totalavarv = 0;
			for(ytterloop = 0; ytterloop <9;ytterloop++)
			{
				// Replace J0=1 
				if(Odds->mh1*Odds->mb1*Odds->mh2*Odds->mb2 <= 5000)
				{
					sUrl.SetAt(sUrl.GetLength()-3,ytterloop+48);
				}
				else
				{
					sUrl = sUrlOrg;
					// sprintf(str, "J0=%c", ytterloop+48);
					// sUrl.Replace("J0=1", str);
					sUrl.SetAt(249,ytterloop+48);
				}
				if(ytterloop == 0)
					maxinner = 8;
				else if(ytterloop == 1)
					maxinner = 7;
				else if(ytterloop ==2)
					maxinner = 7;
				else if(ytterloop ==3)
					maxinner = 7;
				else if(ytterloop ==4)
					maxinner = 5;
				else if(ytterloop ==5)
					maxinner = 4;
				else if(ytterloop ==6)
					maxinner = 3;
				else if(ytterloop == 7)
					maxinner = 3;
				else if(ytterloop == 8)
					maxinner = 0;
				for(innerloop = 0;innerloop <=maxinner;innerloop++)
				{
					int inlasta;
					inlasta = 0;
					if(Odds->mh1*Odds->mb1*Odds->mh2*Odds->mb2 <= 5000)
					{
						CString sUrltmp;
						sUrltmp = sUrl;
						sUrltmp.Insert(500,"&X0=1");
						sUrltmp.SetAt(sUrltmp.GetLength()-3,innerloop+48);
						if(innerloop<maxinner)
						{
							sUrltmp.Insert(500,"&X0=1");
							innerloop++;
							sUrltmp.SetAt(sUrltmp.GetLength()-3,innerloop+48);
						}
						pFile = m_Session.OpenURL(sUrltmp, INTERNET_FLAG_TRANSFER_ASCII);
					}
					else
					{
						sUrl.SetAt(254,innerloop+48);
						pFile = m_Session.OpenURL(sUrl, INTERNET_FLAG_TRANSFER_ASCII);
					}
					if (pFile==NULL)
						return;
					pFile->ReadString( buf, 399 );
					do
					{
						
						if(sscanf(buf,"%d - %d     %d - %d     %d - %d  	 %f,%f",&h1,&b1,&h2,&b2,&h3,&b3,&f1,&f2)>7)
						{
							odds = f1 + (f2/100);
							inlasta++;
							if (Odds->KB[h1][b1][h2][b2][h3][b3] != NULL)
							{	
								if(Odds->KB[h1][b1][h2][b2][h3][b3]->NOdds > 0)
								{
									Odds->KB[h1][b1][h2][b2][h3][b3]->kvot = odds/Odds->KB[h1][b1][h2][b2][h3][b3]->NOdds;
								}
							}
					//	m_progress.SetPos(inlasta/10000);
						}
						else if(sscanf(buf,"%d - %d     %d - %d     %d - %d  	 %f",&h1,&b1,&h2,&b2,&h3,&b3,&odds)>5)
						{
							inlasta++;



							if (Odds->KB[h1][b1][h2][b2][h3][b3] != NULL)
							{	
								Odds->KB[h1][b1][h2][b2][h3][b3]->EjSpelad = true;
								Odds->KB[h1][b1][h2][b2][h3][b3]->kvot=0.0;

				
							}

						}
						
					}
					while(	pFile->ReadString( buf, 399 ));
					totalavarv++;
					if(Odds->mh1*Odds->mb1*Odds->mh2*Odds->mb2 <= 5000)
						m_progress.SetPos(((totalavarv*100)/51)*2);
					else
					m_progress.SetPos((totalavarv*100)/51);
				//	Invalidate(true);
					
				}
				
			}
		}
		m_Session.Close();
		EndDialog(5);
		return;
	}

	// Finsk hockey med 2 matcher -->
	else if (Odds->m_speltyp == 4)
	{
        MessageBox("startar s�kning av sidan...");
        sprintf(sUrlOrg,"http://www.veikkaus.fi/odds/www/GetSysOdds?i=%d&H0=1&H1=1&H2=1&H3=1&H4=1&H5=1&H6=1&H7=1&H8=1&H9=1&V0=1&V1=1&V2=1&V3=1&V4=1&V5=1&V6=1&V7=1&V8=1&V9=1&I0=1&I1=1&I2=1&I3=1&I4=1&I5=1&I6=1&I7=1&I8=1&I9=1&W0=1&W1=1&W2=1&W3=1&W4=1&W5=1&W6=1&W7=1&W8=1&W9=1",
				   Odds->m_matchid);		
		
		pFile = m_Session.OpenURL(sUrlOrg);
		MessageBox("Sidan hittad!");
        if (pFile==NULL)
				return;
		pFile->ReadString( buf, 399 );
		do
		{
						
			if(sscanf(buf,"%d - %d     %d - %d     	 %f,%f",&h1,&b1,&h2,&b2,&f1,&f2)>5)
			{
				odds = f1 + (f2/100);
							



				if (Odds->KB[h1][b1][h2][b2][0][0] != NULL)
				{	
					if(Odds->KB[h1][b1][h2][b2][0][0]->NOdds > 0)
					{
							Odds->KB[h1][b1][h2][b2][0][0]->kvot = odds/Odds->KB[h1][b1][h2][b2][0][0]->NOdds;
					}
				}
						
			}
			else if(sscanf(buf,"%d - %d     %d - %d    	 %f",&h1,&b1,&h2,&b2,&odds)>3)
			{
						

				if (Odds->KB[h1][b1][h2][b2][0][0] != NULL)
				{	
					Odds->KB[h1][b1][h2][b2][0][0]->EjSpelad = true;
					Odds->KB[h1][b1][h2][b2][0][0]->kvot=0.0;
				
				}
			}
						
					}
					while(	pFile->ReadString( buf, 399 ));
					MessageBox("Oddsinl�sning klar!");
		EndDialog(5);
		return;
	}

	
	
	while(franp<=slutsida);
	
	Odds->antalInlastaodds = antalInlastaodds;
	int antaluppfangadeodds;
	antaluppfangadeodds = 0;
	if(Odds->m_speltyp == 0)
	{
		for(int a1=0;a1<=10;a1++)
			for(int a2=0;a2<=10;a2++)
				for(int a3=0;a3<=10;a3++)
					for(int a4=0;a4<=10;a4++)
						for(int a5=0;a5<=10;a5++)
							for(int a6=0;a6<=10;a6++)
							{
								if(Odds->KB[a1][a2][a3][a4][a5][a6]!=NULL)
								{
									if(Odds->KB[a1][a2][a3][a4][a5][a6]->kvot > 0.0005)
										antaluppfangadeodds++;
								}
							}
	}
	//	MessageBox("klar!");
	Odds->antaluppfangadeodds = antaluppfangadeodds;
	Odds->antalmissadeinlastaodds = antalInlastaodds - antaluppfangadeodds;
	m_Session.Close();
	//	EndDialog(5);
}

UINT LasNorskaOdds( LPVOID param )
//void COddsLas::Norskinlasning()
{
	CStdioFile *pFile;

	char  sUrlOrg[300];
	CInternetSession m_Session;
	float odds;
	char buffer[1100];

     // MessageBox("startar s�kning av sidan...");
     //   sprintf(sUrlOrg,"http://www.norsk-tipping.no/wco?event=GETGAMEINFODETAIL&game_id=11&DrawID=257&segmentno=01&frameID=2&eventCount=3");
	 sprintf(sUrlOrg,"http://www.norsk-tipping.no/gar/wco?event=getResultDetails&DrawID=1234&game_id=11&eventCount=3&segmentNo=01&");
	    /* int temposida,temposida2;
		temposida = Odds->m_matchid;
		temposida = ((Odds->m_matchid/100)*100);

		temposida2 = Odds->m_matchid - temposida;
		sUrlOrg[66] = (temposida/100)+48;

		temposida = ((temposida2/10)*10);
		sUrlOrg[67] = (temposida/10)+48;
		
		temposida = temposida2 - ((temposida2/10)*10);
		sUrlOrg[68] = (temposida+48);
		*/
	    sprintf( &sUrlOrg[66],"%d", Odds->m_matchid); 
		sUrlOrg[69+1] = '&';

		int loopindex;
		loopindex = 0;
		
		for(int ytterloopen=loopindex;ytterloopen<=Odds->m_maxsida;ytterloopen++)
		{
			 
		if(ytterloopen<10)
		{
			sUrlOrg[105+1]=(ytterloopen+48);
		}
		else
		{
			int th;
			th = ytterloopen - ((ytterloopen/10)*10);
			sUrlOrg[104+1]=((ytterloopen)/10)+48;
			sUrlOrg[105+1] = th+48;
		}
		
		//pFile = m_Session.OpenURL(sUrlOrg/*,1,INTERNET_FLAG_DONT_CACHE|INTERNET_FLAG_EXISTING_CONNECT|INTERNET_FLAG_TRANSFER_ASCII*/);
		// GB changed 04411024
		::Sleep(300);
		pFile = m_Session.OpenURL(sUrlOrg,1,INTERNET_FLAG_DONT_CACHE|INTERNET_FLAG_EXISTING_CONNECT|INTERNET_FLAG_TRANSFER_ASCII);
		//////////////
		
		// Oddsinl�sningf�nstret st�ngt (genom CANCEL) --> Avsluta
		if (!::IsWindowEnabled((HWND)param))
			return 0;
		
		int nypos;
		//  Uppdatera progress-baren i dialogf�nstret
		// ::PostMessage((HWND)param, WM_ODDSREAD,ytterloopen,0);

        if (pFile==NULL)
				return 0;
		int status;
		status = 0;
		int funnaodds;
		funnaodds = 0;
		int bufferindex;
		bufferindex = 0;
		odds = 0;
		int slut;
		slut = 1;
		
		int tempodds[6][601];
		float tempoddsodds[601];
		for(int gg = 0;gg<=5;gg++)
		{
			for(int hh = 0;hh<=601;hh++)
				tempodds[gg][hh] = 0;
		}
		for(int yy = 0;yy<=601;yy++)
			tempoddsodds[yy] = 0.0;
		int ti1,ti2;
		ti1=0;ti2=1;
		// CStdioFile LoggFile("test.html", CFile::modeCreate | CFile::modeWrite);
		
		for(int bbb=0;bbb<20;bbb++)
			pFile->ReadString( buffer, 1099 );
			 //   for(int ccc=0;ccc<100;ccc++)
			//	{
			//		pFile->ReadString( buffer, 999 );
			//		LoggFile.WriteString(buffer);
			//	}
			//	pFile->ReadString( buffer, 199999 );
			//	LoggFile.WriteString(buffer);
			//	LoggFile.Close();
	
		do
		{

			/* 	if(buffer[bufferindex] == 'n' && status ==0)
				status = 1;
			else if(buffer[bufferindex] =='e' && status == 1)
				status = 2;
			else if(buffer[bufferindex] !='e' && status == 1)
				status = 0;
			else if(buffer[bufferindex] =='w' && status == 2)
				status = 3;
			else if(buffer[bufferindex] == ' ' && status == 3)
				status = 4;*/
			if(buffer[bufferindex] == 'A' && status == 0)
				status = 5;
			else if(buffer[bufferindex] == 'r' && status == 5)
				status = 6;
			else if(buffer[bufferindex] == 'r' && status == 6)
				status = 7;
			else if(buffer[bufferindex] == 'a' && status == 7)
				status = 8;
			else if(buffer[bufferindex] == 'y' && status == 8)
				status = 27;/**TH nytt*/
			else if(buffer[bufferindex] == 'n' && status == 9)
				status = 10;
			else if(buffer[bufferindex] == 'e' && status == 10)
				status = 11;
			else if(buffer[bufferindex] == 'w' && status == 11)
				status = 12;
			else if(buffer[bufferindex] == ' ' && status == 12)
				status = 13;
			else if(buffer[bufferindex] == 'A' && status == 13)
				status = 14;
			else if(buffer[bufferindex] == 'r' && status == 14)
				status = 15;
			else if(buffer[bufferindex] == 'r' && status == 15)
				status = 16;
			else if(buffer[bufferindex] == 'a' && status == 16)
				status = 17;
			else if(buffer[bufferindex] == 'y' && status == 17)
				status = 18;
			else if(buffer[bufferindex] == 'n' && status == 18)
				status = 19;
			else if(buffer[bufferindex] == 'e' && status == 19)
				status = 20;
			else if(buffer[bufferindex] == 'w' && status == 20)
				status = 21;
			else if(buffer[bufferindex] == ' ' && status == 21)
				status = 22;
			else if(buffer[bufferindex] == 'A' && status == 22)
				status = 23;
			else if(buffer[bufferindex] == 'r' && status == 23)
				status = 24;
			else if(buffer[bufferindex] == 'r' && status == 24)
				status = 25;
			else if(buffer[bufferindex] == 'a' && status == 25)
				status = 26;
			else if(buffer[bufferindex] == 'y' && status == 26)
				status = 27;
			else if(buffer[bufferindex] == ']' && status == 27)/*th nytt*/
				status = 28;
			else if(buffer[bufferindex] >= '0' && buffer[bufferindex]<= '9' && status == 28)
				odds = 10*odds + (buffer[bufferindex]-48);
			else if(buffer[bufferindex] == ',' && status == 28)
			{
				tempodds[ti1][ti2] = odds;
				ti2++;
				odds = 0;
			}
			else if(buffer[bufferindex] == ']' && status == 28)/*TH nytt*/
				status = 29;
			else if(buffer[bufferindex] == '[' && status == 29)/*TH nytt*/
			{
				status = 30;
				ti1++;
				ti2 = 1;
				odds = 0;
			}
			else if(buffer[bufferindex] >= '0' && buffer[bufferindex]<= '9' && status == 30)
				odds = 10*odds + (buffer[bufferindex]-48);
			else if(buffer[bufferindex] == ',' && status == 30)
			{
				tempodds[ti1][ti2] = odds;
				ti2++;
				odds = 0;
			}
			else if(buffer[bufferindex] == ']' && status == 30)/*th nytt*/
			{
				status = 31;
				ti1++;
				ti2 = 1;
				odds = 0;
			}
			else if(buffer[bufferindex] == '[' && status == 31)/*th nytt*/
				status = 32;
			else if(buffer[bufferindex] == '[' && status == 32)/*TH nytt*/
				status = 33;

			else if(buffer[bufferindex] >= '0' && buffer[bufferindex]<= '9' && status == 33)
				odds = 10*odds + (buffer[bufferindex]-48);
			else if(buffer[bufferindex] == ',' && status == 33)
			{
				tempodds[ti1][ti2] = odds;
				ti2++;
				odds = 0;
			}
			else if(buffer[bufferindex] == ']' && status == 33)/*th nytt*/
				status = 34;
			else if(buffer[bufferindex] == '[' && status == 34)/*th nytt*/
			{
				status = 35;
				ti1++;
				ti2 = 1;
				odds = 0;
			}
			else if(buffer[bufferindex] >= '0' && buffer[bufferindex]<= '9' && status == 35)
				odds = 10*odds + (buffer[bufferindex]-48);
			else if(buffer[bufferindex] == ',' && status == 35)
			{
				tempodds[ti1][ti2] = odds;
				ti2++;
				odds = 0;
			}
			else if(buffer[bufferindex] == ']' && status == 35)/*th nytt*/
			{
				status = 36;
				ti1++;
				ti2 = 1;
				odds = 0;
			}
			else if(buffer[bufferindex] == '[' && status == 36)/*th nytt*/
				status = 37;
			else if(buffer[bufferindex] == '[' && status == 37)/*th nytt*/
				status = 38;

			else if(buffer[bufferindex] >= '0' && buffer[bufferindex]<= '9' && status == 38)
				odds = 10*odds + (buffer[bufferindex]-48);
			else if(buffer[bufferindex] == ',' && status == 38)
			{
				tempodds[ti1][ti2] = odds;
				ti2++;
				odds = 0;
			}
			else if(buffer[bufferindex] == ']' && status == 38)/*th nytt*/
				status = 39;
			else if(buffer[bufferindex] == '[' && status == 39)/*th nytt*/
			{
				status = 40;
				ti1++;
				ti2 = 1;
				odds = 0;
			}
			else if(buffer[bufferindex] >= '0' && buffer[bufferindex]<= '9' && status == 40)
				odds = 10*odds + (buffer[bufferindex]-48);
			else if(buffer[bufferindex] == ',' && status == 40)
			{
				tempodds[ti1][ti2] = odds;
				ti2++;
				odds = 0;
			}
			else if(buffer[bufferindex] == ']' && status == 40)/*th nytt*/
			{
				status = 41;
				ti1++;
				ti2 = 1;
				odds = 0;
			}
			else if(buffer[bufferindex] == '(' && status == 41)/*th nytt*/
				status = 42;
			else if(buffer[bufferindex] >= '0' && buffer[bufferindex]<= '9' && status == 42)
				odds = 10*odds + (buffer[bufferindex]-48);
			else if(buffer[bufferindex] == '.' && status == 42)
			{
				tempoddsodds[ti2] = odds;
				status = 43;
			}
			else if(buffer[bufferindex] >= '0' && buffer[bufferindex]<= '9' && status == 43)
			{
				tempoddsodds[ti2] += 0.1*(buffer[bufferindex]-48);
				odds = 0;
				status = 44;
			}
			else if(buffer[bufferindex] >= '0' && buffer[bufferindex]<= '9' && status == 44)
			{
				tempoddsodds[ti2] += 0.01*(buffer[bufferindex]-48);
				odds = 0;
			}
			else if(buffer[bufferindex] == ',' && (status ==44))
			{
				status = 42;
				ti2++;
			}
			else if(buffer[bufferindex] == ')' && status == 44)
				status = 45;
			//	else
				//	status = 0;

		    bufferindex++;
			if(bufferindex == 1099)
			{
				bufferindex = 0;
				pFile->ReadString( buffer, 1099 );
			}
			
						
		}
		while(status<45);
		

		for(int xxx=1;xxx<=600;xxx++)
		{
			//**Tommy start 2003-10-10**//
			if(Odds->m_speltyp==6)
			{
				//***Tommy slut 2003-10-10**//
				if ((tempodds[0][xxx] < 11) && (tempodds[1][xxx] < 11) && (tempodds[2][xxx] < 11) && (tempodds[3][xxx] < 11) &&
					(tempodds[4][xxx] < 11) && (tempodds[5][xxx] < 11) &&
					Odds->KB[tempodds[0][xxx]][tempodds[1][xxx]][tempodds[2][xxx]][tempodds[3][xxx]][tempodds[4][xxx]][tempodds[5][xxx]] != NULL)
				{	
					if(Odds->KB[tempodds[0][xxx]][tempodds[1][xxx]][tempodds[2][xxx]][tempodds[3][xxx]][tempodds[4][xxx]][tempodds[5][xxx]]->NOdds > 0)
					{
						Odds->KB[tempodds[0][xxx]][tempodds[1][xxx]][tempodds[2][xxx]][tempodds[3][xxx]][tempodds[4][xxx]][tempodds[5][xxx]]->kvot = *(Odds->KvotJust) * tempoddsodds[xxx]/Odds->KB[tempodds[0][xxx]][tempodds[1][xxx]][tempodds[2][xxx]][tempodds[3][xxx]][tempodds[4][xxx]][tempodds[5][xxx]]->NOdds;
						Odds->KB[tempodds[0][xxx]][tempodds[1][xxx]][tempodds[2][xxx]][tempodds[3][xxx]][tempodds[4][xxx]][tempodds[5][xxx]]->EjSpelad = false;

						// R�kna upp antal inl�sta odds
						if (!Odds->last[tempodds[0][xxx]][tempodds[1][xxx]][tempodds[2][xxx]][tempodds[3][xxx]][tempodds[4][xxx]][tempodds[5][xxx]])
							Odds->NumOdds ++;
						Odds->last[tempodds[0][xxx]][tempodds[1][xxx]][tempodds[2][xxx]][tempodds[3][xxx]][tempodds[4][xxx]][tempodds[5][xxx]] = true;
						
						

					}
				}
				//***Tommy Start 2003-10-10**//
			}
			else if(Odds->m_speltyp==7)
			{
				//**Tommy Slut 2003-10-10**//
				if ((tempodds[0][xxx] < 11) && (tempodds[1][xxx] < 11) && (tempodds[2][xxx] < 11) && (tempodds[3][xxx] < 11) &&
				     Odds->KB[tempodds[0][xxx]][tempodds[1][xxx]][tempodds[2][xxx]][tempodds[3][xxx]][0][0] != NULL)
				{ 
					if(Odds->KB[tempodds[0][xxx]][tempodds[1][xxx]][tempodds[2][xxx]][tempodds[3][xxx]][0][0]->NOdds > 0)
					{
						Odds->KB[tempodds[0][xxx]][tempodds[1][xxx]][tempodds[2][xxx]][tempodds[3][xxx]][0][0]->kvot = *(Odds->KvotJust) * tempoddsodds[xxx]/Odds->KB[tempodds[0][xxx]][tempodds[1][xxx]][tempodds[2][xxx]][tempodds[3][xxx]][0][0]->NOdds;
						Odds->KB[tempodds[0][xxx]][tempodds[1][xxx]][tempodds[2][xxx]][tempodds[3][xxx]][0][0]->EjSpelad = false;
						// R�kna upp antal inl�sta odds
						if (!Odds->last[tempodds[0][xxx]][tempodds[1][xxx]][tempodds[2][xxx]][tempodds[3][xxx]][0][0])
							Odds->NumOdds ++;
						Odds->last[tempodds[0][xxx]][tempodds[1][xxx]][tempodds[2][xxx]][tempodds[3][xxx]][0][0] = true;
					}
				}
				//**Tommy Start 2003-10-10**//
			}
			//**Tommy Slut 2003-10-10**//
		}
		/*	segmentindex.Open( "segmentindex.txt", CFile::modeWrite    , 0 );
		sprintf(buf, "%d\n",DrawIDNo);
		segmentindex.WriteString(buf);
		sprintf(buf, "%d",ytterloopen);
		segmentindex.WriteString(buf);
		segmentindex.Close();
		char tbuffer1[10],tbuffer2[4],tbuffer3[4],tbuffer4[4],tbuffer5[4],tbuffer6[4];
		hemma1.SeekToEnd();
	
		for(int tt = 1; tt<601;tt++)
		{
			sprintf(tbuffer1,"%d\n",tempodds[0][tt]);
			hemma1.WriteString(tbuffer1);
			sprintf(tbuffer1,"%d\n",tempodds[1][tt]);
			hemma1.WriteString(tbuffer1);
			sprintf(tbuffer1,"%d\n",tempodds[2][tt]);
			hemma1.WriteString(tbuffer1);
			sprintf(tbuffer1,"%d\n",tempodds[3][tt]);
			hemma1.WriteString(tbuffer1);
			sprintf(tbuffer1,"%d\n",tempodds[4][tt]);
			hemma1.WriteString(tbuffer1);
			sprintf(tbuffer1,"%d\n",tempodds[5][tt]);
			hemma1.WriteString(tbuffer1);
			sprintf(tbuffer1,"%f\n",tempoddsodds[tt]);
			hemma1.WriteString(tbuffer1);
		
		}*/
		pFile->Close();

		//  Uppdatera progress-baren i dialogf�nstret
		::PostMessage((HWND)param, WM_ODDSREAD,ytterloopen,0);
		}
		
	// hemma1.Close();
	::PostMessage((HWND)param, WM_ODDSFINISHED,0,0);
	return 0;
}


void COddsLas::NollaOdds()
{
   Odds->NumOdds = 0;	// Nollst�ll antal inl�sta odds
   for(int t1 = 0;t1<10;t1++)
	 for(int t2 = 0;t2<10;t2++)
		for(int t3 = 0;t3<10;t3++)
    		for(int t4 = 0;t4<10;t4++)
				for(int t5 = 0;t5<10;t5++)
					for(int t6 = 0;t6<10;t6++)
					{
						if (Odds->KB[t1][t2][t3][t4][t5][t6] != NULL)
						{
							Odds->KB[t1][t2][t3][t4][t5][t6]->EjSpelad = true;
							Odds->KB[t1][t2][t3][t4][t5][t6]->kvot=0.0;
							Odds->last[t1][t2][t3][t4][t5][t6] = false;
							
						}
			
					}
}
void COddsLas::Norskinlasning()
{
	if (Odds->m_OspeladeForvalt)
	   NollaOdds();

	m_progress.SetRange( 0, Odds->m_maxsida);
	// Starta tr�dinl�sning
	HWND hwnd = GetSafeHwnd();
	Thread = AfxBeginThread(LasNorskaOdds,hwnd);

	//EndDialog(5);

}
BOOL COddsLas::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	Thread = NULL;
	m_AntalInlastaOdds = Odds->NumOdds;
	m_MissadeSidor = Odds->MissadeSidor;
	m_upprepa = Odds->m_UpprepaForvalt;
	UpdateData(false);
	ShowWindow(SW_SHOW);
	RedrawWindow();
	if  (Odds->m_speltyp <= 2 || Odds->m_speltyp == 8)
		Svenskinlasning();
	else if  (Odds->m_speltyp >= 6)
		Norskinlasning();

	else
		Finskinlasning(0,0);
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void COddsLas::OnCancel() 
{
	// TODO: Add extra cleanup here
	
	CDialog::OnCancel();
	int treadexit = ::TerminateThread(Thread, 0);
}


void COddsLas::OnOK() 
{
	// Don't finnish on <Return>
}
